package com.example

import com.example.data.model.GymDateUtils
import com.example.data.model.SubscriptionEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun `generateRandomMemberCode matches KH format`() {
        val code = GymDateUtils.generateRandomMemberCode()
        assertTrue(code.startsWith("KH"))
        assertEquals(7, code.length)
    }

    @Test
    fun `freezeAt and unfreezeAt manage status timestamps and freeze_days_available accurately`() {
        val dayMillis = 86_400_000L
        val activatedTime = 1_700_000_000_000L
        val initialExpires = activatedTime + 90 * dayMillis

        val activeSub = SubscriptionEntity(
            code = "KH8492A",
            order_number = "ORD-294810",
            full_name = "أحمد محمود الشناوي",
            phone = "01012345678",
            gender_category = "قسم الرجال",
            package_id = "pkg_3m",
            package_title = "باقة 3 شهور",
            price_paid_egp = 1250,
            duration_months = 3,
            total_days = 90,
            remaining_days = 90,
            start_date = GymDateUtils.formatIsoDate(activatedTime),
            end_date = GymDateUtils.formatIsoDate(initialExpires),
            status_code = "ACTIVE",
            status_ar = "نشط ومفعل",
            created_at_utc_millis = activatedTime,
            activated_at_utc_millis = activatedTime,
            expires_at_utc_millis = initialExpires,
            frozen_at_utc_millis = null,
            accumulated_freeze_millis = 0L,
            freeze_days_available = 15,
            free_invitations_left = 4
        )

        // 1. Freeze after 20 days (70 days remaining)
        val freezeTime = activatedTime + 20 * dayMillis
        val frozenSub = activeSub.freezeAt(freezeTime)

        assertEquals("FROZEN", frozenSub.status_code)
        assertEquals(freezeTime, frozenSub.frozen_at_utc_millis)
        assertEquals(70, frozenSub.remaining_days)

        // Verify countdown is stopped even 5 days later while still FROZEN
        val fiveDaysIntoFreeze = freezeTime + 5 * dayMillis
        assertEquals(70, frozenSub.computeLiveRemainingDays(fiveDaysIntoFreeze))

        // 2. Unfreeze after 5 days of freeze
        val unfreezeTime = freezeTime + 5 * dayMillis
        val unfrozenSub = frozenSub.unfreezeAt(unfreezeTime)

        val expectedFreezeDuration = 5 * dayMillis
        assertEquals("ACTIVE", unfrozenSub.status_code)
        assertNull(unfrozenSub.frozen_at_utc_millis)
        assertEquals(initialExpires + expectedFreezeDuration, unfrozenSub.expires_at_utc_millis)
        assertEquals(expectedFreezeDuration, unfrozenSub.accumulated_freeze_millis)
        assertEquals(10, unfrozenSub.freeze_days_available) // 15 - 5 = 10 days left
        assertEquals(70, unfrozenSub.remaining_days) // Resumes from 70 remaining days

        // Verify countdown resumes as time progresses after unfreeze (e.g., 10 days after unfreeze -> 60 days left)
        val tenDaysAfterUnfreeze = unfreezeTime + 10 * dayMillis
        assertEquals(60, unfrozenSub.computeLiveRemainingDays(tenDaysAfterUnfreeze))
    }
}
