package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.CaptainHimaHeroHeader
import com.example.ui.components.LiveStatisticsRow
import com.example.ui.screens.BookingsScreen
import com.example.ui.screens.GymSettingsScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.StoriesScreen
import com.example.ui.screens.SubscriptionsScreen
import com.example.ui.theme.CaptainHimaGymTheme
import com.example.ui.theme.StatusPendingAmber
import com.example.ui.viewmodel.AdminSection
import com.example.ui.viewmodel.GymAdminViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: GymAdminViewModel = viewModel()
            val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()

            CaptainHimaGymTheme(darkTheme = isDarkTheme) {
                CaptainHimaAdminRoot(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun CaptainHimaAdminRoot(viewModel: GymAdminViewModel) {
    val context = LocalContext.current
    val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()
    val isAdminAuthenticated by viewModel.isAdminAuthenticated.collectAsStateWithLifecycle()
    val currentSection by viewModel.currentSection.collectAsStateWithLifecycle()
    val syncStatus by viewModel.syncStatus.collectAsStateWithLifecycle()
    val liveStats by viewModel.liveStats.collectAsStateWithLifecycle()
    val filteredSubscriptions by viewModel.filteredSubscriptions.collectAsStateWithLifecycle()
    val allSubscriptions by viewModel.allSubscriptions.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val statusFilter by viewModel.statusFilter.collectAsStateWithLifecycle()
    val genderFilter by viewModel.genderFilter.collectAsStateWithLifecycle()
    val bookings by viewModel.bookings.collectAsStateWithLifecycle()
    val stories by viewModel.stories.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val gymConfig by viewModel.gymConfig.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
    val verifierCodeInput by viewModel.verifierCodeInput.collectAsStateWithLifecycle()
    val verifiedSubscription by viewModel.verifiedSubscription.collectAsStateWithLifecycle()
    val verifierFeedback by viewModel.verifierFeedback.collectAsStateWithLifecycle()
    val isUploadingMedia by viewModel.isUploadingMedia.collectAsStateWithLifecycle()
    val savedSupabaseUrl by viewModel.savedSupabaseUrl.collectAsStateWithLifecycle()
    val savedSupabaseKey by viewModel.savedSupabaseKey.collectAsStateWithLifecycle()

    var showVerifierModal by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(toastMessage) {
        val msg = toastMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    // BackHandler for secondary tabs to return to SUBSCRIPTIONS tab
    BackHandler(enabled = isAdminAuthenticated && currentSection != AdminSection.SUBSCRIPTIONS) {
        viewModel.selectSection(AdminSection.SUBSCRIPTIONS)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            if (isAdminAuthenticated) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 10.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    val navItems = listOf(
                        Triple(AdminSection.SUBSCRIPTIONS, "الاشتراكات", Icons.Default.CardMembership),
                        Triple(AdminSection.BOOKINGS, "الحجوزات", Icons.Default.EventNote),
                        Triple(AdminSection.STORIES, "القصص", Icons.Default.SlowMotionVideo),
                        Triple(AdminSection.NOTIFICATIONS, "الإشعارات", Icons.Default.Notifications),
                        Triple(AdminSection.SETTINGS, "الإعدادات", Icons.Default.Settings)
                    )

                    navItems.forEach { (section, label, icon) ->
                        val selected = currentSection == section
                        val badgeCount = when (section) {
                            AdminSection.SUBSCRIPTIONS -> liveStats.pendingCount
                            AdminSection.BOOKINGS -> liveStats.pendingBookingsCount
                            else -> 0
                        }

                        NavigationBarItem(
                            selected = selected,
                            onClick = { viewModel.selectSection(section) },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (badgeCount > 0) {
                                            Badge(
                                                containerColor = StatusPendingAmber,
                                                contentColor = MaterialTheme.colorScheme.onPrimary
                                            ) {
                                                Text(badgeCount.toString())
                                            }
                                        }
                                    }
                                ) {
                                    Icon(imageVector = icon, contentDescription = label)
                                }
                            },
                            label = {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                            ),
                            modifier = Modifier.testTag("nav_tab_${section.name.lowercase()}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (!isAdminAuthenticated) {
                LoginScreen(
                    isDarkTheme = isDarkTheme,
                    syncStatus = syncStatus,
                    onToggleTheme = { viewModel.toggleTheme() },
                    onLoginSubmit = { email, pin ->
                        viewModel.loginAdmin(email, pin)
                    }
                )
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    CaptainHimaHeroHeader(
                        isDarkTheme = isDarkTheme,
                        syncStatus = syncStatus,
                        onToggleTheme = { viewModel.toggleTheme() },
                        onOpenVerifier = { showVerifierModal = true },
                        onSyncClick = { viewModel.triggerSupabaseSync() },
                        onLogoutClick = { viewModel.logoutAdmin() }
                    )

                    // Live Top Statistics Strip
                    LiveStatisticsRow(
                        stats = liveStats,
                        selectedStatusFilter = statusFilter,
                        onStatusCardClick = { status ->
                            viewModel.updateStatusFilter(status)
                            viewModel.selectSection(AdminSection.SUBSCRIPTIONS)
                        }
                    )

                    Crossfade(
                        targetState = currentSection,
                        modifier = Modifier.weight(1f),
                        label = "sectionCrossfade"
                    ) { section ->
                        when (section) {
                            AdminSection.SUBSCRIPTIONS -> {
                                SubscriptionsScreen(
                                    subscriptions = filteredSubscriptions,
                                    allSubscriptions = allSubscriptions,
                                    searchQuery = searchQuery,
                                    statusFilter = statusFilter,
                                    genderFilter = genderFilter,
                                    packageCatalog = viewModel.getPackageCatalog(),
                                    showVerifierModal = showVerifierModal,
                                    verifierCodeInput = verifierCodeInput,
                                    verifiedSubscription = verifiedSubscription,
                                    verifierFeedback = verifierFeedback,
                                    onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                                    onStatusFilterChange = { viewModel.updateStatusFilter(it) },
                                    onGenderFilterChange = { viewModel.updateGenderFilter(it) },
                                    onApprove = { viewModel.approveSubscription(it) },
                                    onReject = { viewModel.rejectSubscription(it) },
                                    onToggleFreeze = { viewModel.toggleFreezeSubscription(it) },
                                    onUpdateFreezeDaysAvailable = { sub, newDays ->
                                        viewModel.updateFreezeDaysAvailable(sub, newDays)
                                    },
                                    onExtendDays = { sub, days -> viewModel.extendSubscription(sub, days) },
                                    onUseInvitation = { viewModel.useOneFreeInvitation(it) },
                                    onDeleteSubscription = { viewModel.deleteSubscription(it) },
                                    onWhatsAppMember = { viewModel.openWhatsAppForMember(context, it) },
                                    onCreateMember = { code, name, phone, gender, pkg, price, activate ->
                                        viewModel.createNewMember(code, name, phone, gender, pkg, price, activate)
                                    },
                                    onOpenVerifierModal = { showVerifierModal = true },
                                    onCloseVerifierModal = {
                                        showVerifierModal = false
                                        viewModel.clearVerifiedSubscription()
                                    },
                                    onVerifierInputChange = { viewModel.updateVerifierInput(it) },
                                    onVerifyCode = { viewModel.verifyMemberCode(it) }
                                )
                            }

                            AdminSection.BOOKINGS -> {
                                BookingsScreen(
                                    bookings = bookings,
                                    onUpdateBookingStatus = { bk, status ->
                                        viewModel.updateBookingStatus(bk, status)
                                    },
                                    onDeleteBooking = { viewModel.deleteBooking(it) }
                                )
                            }

                            AdminSection.STORIES -> {
                                StoriesScreen(
                                    stories = stories,
                                    isUploadingMedia = isUploadingMedia,
                                    onUploadGalleryMedia = { uri, onUploaded ->
                                        viewModel.uploadMediaFromGallery(context, uri, onUploaded)
                                    },
                                    onSaveStory = { viewModel.saveStory(it) },
                                    onToggleStoryActive = { viewModel.toggleStoryActive(it) },
                                    onDeleteStory = { viewModel.deleteStory(it) },
                                    onOpenVideoUrl = { viewModel.openExternalUrl(context, it) }
                                )
                            }

                            AdminSection.NOTIFICATIONS -> {
                                NotificationsScreen(
                                    notifications = notifications,
                                    subscriptions = allSubscriptions,
                                    isUploadingMedia = isUploadingMedia,
                                    onUploadGalleryMedia = { uri, onUploaded ->
                                        viewModel.uploadMediaFromGallery(context, uri, onUploaded)
                                    },
                                    onOpenMediaUrl = { viewModel.openExternalUrl(context, it) },
                                    onSendOrUpdateNotification = { id, title, msg, type, target ->
                                        viewModel.sendOrUpdateNotification(id, title, msg, type, target)
                                    },
                                    onDeleteNotification = { viewModel.deleteNotification(it) }
                                )
                            }

                            AdminSection.SETTINGS -> {
                                GymSettingsScreen(
                                    gymConfig = gymConfig,
                                    isDarkTheme = isDarkTheme,
                                    syncStatus = syncStatus,
                                    initialSupabaseUrl = savedSupabaseUrl,
                                    initialSupabaseKey = savedSupabaseKey,
                                    onSetDarkTheme = { viewModel.setDarkTheme(it) },
                                    onSaveConfig = { viewModel.saveGymConfig(it) },
                                    onSaveSupabaseCredentials = { url, key ->
                                        viewModel.saveSupabaseCredentialsAndSync(url, key)
                                    },
                                    onSyncSupabase = { viewModel.triggerSupabaseSync() },
                                    onOpenUrl = { viewModel.openExternalUrl(context, it) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
