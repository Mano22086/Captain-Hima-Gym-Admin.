package com.example.data.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.ceil
import kotlin.math.max

/**
 * 1. جدول الاشتراكات والعضويات (subscriptions)
 * Matches all required columns verbatim for client & Supabase compatibility.
 */
@Entity(tableName = "subscriptions")
@JsonClass(generateAdapter = true)
data class SubscriptionEntity(
    @PrimaryKey
    @ColumnInfo(name = "code")
    @Json(name = "code")
    val code: String,

    @ColumnInfo(name = "order_number")
    @Json(name = "order_number")
    val order_number: String,

    @ColumnInfo(name = "full_name")
    @Json(name = "full_name")
    val full_name: String,

    @ColumnInfo(name = "phone")
    @Json(name = "phone")
    val phone: String,

    @ColumnInfo(name = "gender_category")
    @Json(name = "gender_category")
    val gender_category: String, // 'قسم الرجال' أو 'قسم السيدات'

    @ColumnInfo(name = "package_id")
    @Json(name = "package_id")
    val package_id: String, // 'pkg_1m', 'pkg_3m', 'pkg_6m', 'pkg_12m'

    @ColumnInfo(name = "package_title")
    @Json(name = "package_title")
    val package_title: String,

    @ColumnInfo(name = "price_paid_egp")
    @Json(name = "price_paid_egp")
    val price_paid_egp: Int,

    @ColumnInfo(name = "duration_months")
    @Json(name = "duration_months")
    val duration_months: Int, // 1, 3, 6, 12

    @ColumnInfo(name = "total_days")
    @Json(name = "total_days")
    val total_days: Int, // 30, 90, 180, 360

    @ColumnInfo(name = "remaining_days")
    @Json(name = "remaining_days")
    val remaining_days: Int,

    @ColumnInfo(name = "start_date")
    @Json(name = "start_date")
    val start_date: String, // YYYY-MM-DD

    @ColumnInfo(name = "end_date")
    @Json(name = "end_date")
    val end_date: String, // YYYY-MM-DD

    @ColumnInfo(name = "status_code")
    @Json(name = "status_code")
    val status_code: String, // 'PENDING', 'ACTIVE', 'FROZEN', 'EXPIRED', 'REJECTED', 'CANCELLED'

    @ColumnInfo(name = "status_ar")
    @Json(name = "status_ar")
    val status_ar: String,

    @ColumnInfo(name = "created_at_utc_millis")
    @Json(name = "created_at_utc_millis")
    val created_at_utc_millis: Long,

    @ColumnInfo(name = "activated_at_utc_millis")
    @Json(name = "activated_at_utc_millis")
    val activated_at_utc_millis: Long? = null,

    @ColumnInfo(name = "expires_at_utc_millis")
    @Json(name = "expires_at_utc_millis")
    val expires_at_utc_millis: Long? = null,

    @ColumnInfo(name = "frozen_at_utc_millis")
    @Json(name = "frozen_at_utc_millis")
    val frozen_at_utc_millis: Long? = null,

    @ColumnInfo(name = "accumulated_freeze_millis")
    @Json(name = "accumulated_freeze_millis")
    val accumulated_freeze_millis: Long = 0L,

    @ColumnInfo(name = "freeze_days_available")
    @Json(name = "freeze_days_available")
    val freeze_days_available: Int = 7,

    @ColumnInfo(name = "free_invitations_left")
    @Json(name = "free_invitations_left")
    val free_invitations_left: Int = 2
) {
    /**
     * Dynamically computes the live remaining days based on status_code,
     * expires_at_utc_millis, and frozen_at_utc_millis:
     * - When FROZEN: stops the countdown at the exact timestamp `frozen_at_utc_millis`.
     * - When ACTIVE: counts down dynamically against `nowMillis`.
     */
    fun computeLiveRemainingDays(nowMillis: Long = System.currentTimeMillis()): Int {
        return when (status_code) {
            "PENDING" -> total_days
            "REJECTED", "CANCELLED", "EXPIRED" -> 0
            "FROZEN" -> {
                val expires = expires_at_utc_millis
                val frozenAt = frozen_at_utc_millis
                if (expires != null && frozenAt != null) {
                    val diffMillis = max(0L, expires - frozenAt)
                    ceil(diffMillis.toDouble() / 86_400_000.0).toInt()
                } else {
                    remaining_days
                }
            }
            "ACTIVE" -> {
                val expires = expires_at_utc_millis
                if (expires != null) {
                    val diffMillis = max(0L, expires - nowMillis)
                    ceil(diffMillis.toDouble() / 86_400_000.0).toInt()
                } else {
                    remaining_days
                }
            }
            else -> remaining_days
        }
    }

    /**
     * Calculates the current active freeze duration in milliseconds if the subscription is FROZEN.
     */
    fun computeCurrentFreezeDurationMillis(nowMillis: Long = System.currentTimeMillis()): Long {
        if (status_code != "FROZEN" || frozen_at_utc_millis == null) return 0L
        return max(0L, nowMillis - frozen_at_utc_millis)
    }

    /**
     * Calculates how many freeze days are consumed by a given freeze duration in milliseconds.
     */
    fun computeFrozenDaysUsed(freezeDurationMillis: Long): Int {
        if (freezeDurationMillis <= 0L) return 1
        return ceil(freezeDurationMillis.toDouble() / 86_400_000.0).toInt().coerceAtLeast(1)
    }

    /**
     * Freezes an active subscription at `nowMillis`:
     * - Updates `status_code` to 'FROZEN'
     * - Records `frozen_at_utc_millis = nowMillis`
     * - Stops the countdown of `remaining_days`
     */
    fun freezeAt(nowMillis: Long = System.currentTimeMillis()): SubscriptionEntity {
        val currentExpires = expires_at_utc_millis
            ?: (nowMillis + remaining_days.toLong() * 86_400_000L)
        val pausedRemainingDays = ceil(max(0L, currentExpires - nowMillis).toDouble() / 86_400_000.0).toInt()
        return copy(
            status_code = "FROZEN",
            status_ar = "مجمد مؤقتاً",
            frozen_at_utc_millis = nowMillis,
            expires_at_utc_millis = currentExpires,
            remaining_days = pausedRemainingDays
        )
    }

    /**
     * Unfreezes a frozen subscription at `nowMillis`:
     * - Calculates freeze duration (`nowMillis - frozen_at_utc_millis`)
     * - Adds this duration to `expires_at_utc_millis` and `accumulated_freeze_millis`
     * - Updates `status_code` back to 'ACTIVE'
     * - Resumes `remaining_days` countdown from the new expiry timestamp
     * - Deducts consumed freeze days from `freeze_days_available`
     */
    fun unfreezeAt(nowMillis: Long = System.currentTimeMillis()): SubscriptionEntity {
        val frozenAt = frozen_at_utc_millis ?: nowMillis
        val freezeDurationMillis = max(0L, nowMillis - frozenAt)
        val baseExpires = expires_at_utc_millis
            ?: (frozenAt + remaining_days.toLong() * 86_400_000L)
        val newExpiresAt = baseExpires + freezeDurationMillis
        val newAccumulatedFreeze = accumulated_freeze_millis + freezeDurationMillis
        val frozenDaysUsed = computeFrozenDaysUsed(freezeDurationMillis)
        val newFreezeDaysAvailable = max(0, freeze_days_available - frozenDaysUsed)
        val resumedRemainingDays = ceil(max(0L, newExpiresAt - nowMillis).toDouble() / 86_400_000.0).toInt()

        return copy(
            status_code = "ACTIVE",
            status_ar = "نشط ومفعل",
            expires_at_utc_millis = newExpiresAt,
            frozen_at_utc_millis = null,
            accumulated_freeze_millis = newAccumulatedFreeze,
            freeze_days_available = newFreezeDaysAvailable,
            remaining_days = resumedRemainingDays,
            end_date = GymDateUtils.formatIsoDate(newExpiresAt)
        )
    }
}

/**
 * 2. جدول طلبات الحجز (bookings)
 */
@Entity(tableName = "bookings")
@JsonClass(generateAdapter = true)
data class BookingEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    @Json(name = "id")
    val id: String,

    @ColumnInfo(name = "order_number")
    @Json(name = "order_number")
    val order_number: String,

    @ColumnInfo(name = "reference_code")
    @Json(name = "reference_code")
    val reference_code: String,

    @ColumnInfo(name = "full_name")
    @Json(name = "full_name")
    val full_name: String,

    @ColumnInfo(name = "phone")
    @Json(name = "phone")
    val phone: String,

    @ColumnInfo(name = "gender_category")
    @Json(name = "gender_category")
    val gender_category: String,

    @ColumnInfo(name = "booking_type")
    @Json(name = "booking_type")
    val booking_type: String,

    @ColumnInfo(name = "selected_item_name")
    @Json(name = "selected_item_name")
    val selected_item_name: String,

    @ColumnInfo(name = "price_egp")
    @Json(name = "price_egp")
    val price_egp: Int,

    @ColumnInfo(name = "preferred_date_time")
    @Json(name = "preferred_date_time")
    val preferred_date_time: String,

    @ColumnInfo(name = "notes")
    @Json(name = "notes")
    val notes: String,

    @ColumnInfo(name = "status")
    @Json(name = "status")
    val status: String, // 'PENDING', 'ACTIVE', 'REJECTED'

    @ColumnInfo(name = "created_at_utc_millis")
    @Json(name = "created_at_utc_millis")
    val created_at_utc_millis: Long
)

/**
 * 3. جدول القصص والفيديوهات (stories)
 */
@Entity(tableName = "stories")
@JsonClass(generateAdapter = true)
data class StoryEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    @Json(name = "id")
    val id: String,

    @ColumnInfo(name = "title")
    @Json(name = "title")
    val title: String,

    @ColumnInfo(name = "subtitle")
    @Json(name = "subtitle")
    val subtitle: String,

    @ColumnInfo(name = "badge_text")
    @Json(name = "badge_text")
    val badge_text: String,

    @ColumnInfo(name = "category_tag")
    @Json(name = "category_tag")
    val category_tag: String, // 'صالة الحديد', 'الحصص الجماعية', 'السبا والجاكوزي', 'قسم السيدات'

    @ColumnInfo(name = "program_to_book")
    @Json(name = "program_to_book")
    val program_to_book: String,

    @ColumnInfo(name = "booking_type_preset")
    @Json(name = "booking_type_preset")
    val booking_type_preset: String, // 'اشتراك باقة' أو 'حجز حصة جماعية'

    @ColumnInfo(name = "gender_preset")
    @Json(name = "gender_preset")
    val gender_preset: String, // 'قسم الرجال' أو 'قسم السيدات'

    @ColumnInfo(name = "video_url")
    @Json(name = "video_url")
    val video_url: String,

    @ColumnInfo(name = "audio_track_title")
    @Json(name = "audio_track_title")
    val audio_track_title: String,

    @ColumnInfo(name = "likes_count")
    @Json(name = "likes_count")
    val likes_count: Int,

    @ColumnInfo(name = "shares_count")
    @Json(name = "shares_count")
    val shares_count: Int,

    @ColumnInfo(name = "sort_order")
    @Json(name = "sort_order")
    val sort_order: Int,

    @ColumnInfo(name = "is_active")
    @Json(name = "is_active")
    val is_active: Boolean
)

/**
 * 4. جدول الأخبار والإشعارات والعروض (notifications)
 */
@Entity(tableName = "notifications")
@JsonClass(generateAdapter = true)
data class NotificationEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    @Json(name = "id")
    val id: String,

    @ColumnInfo(name = "title")
    @Json(name = "title")
    val title: String,

    @ColumnInfo(name = "message")
    @Json(name = "message")
    val message: String,

    @ColumnInfo(name = "type")
    @Json(name = "type")
    val type: String, // 'ACTIVATED', 'PROMO', 'ANNOUNCEMENT'

    @ColumnInfo(name = "target_code")
    @Json(name = "target_code")
    val target_code: String, // 'ALL' أو كود مشترك محدد مثل KH8492A

    @ColumnInfo(name = "is_read")
    @Json(name = "is_read")
    val is_read: Boolean = false,

    @ColumnInfo(name = "created_at_utc_millis")
    @Json(name = "created_at_utc_millis")
    val created_at_utc_millis: Long
)

/**
 * 5. جدول إعدادات النادي وأسعار الباقات والروابط (gym_config) — الصف الأساسي id = 'main'
 */
@Entity(tableName = "gym_config")
@JsonClass(generateAdapter = true)
data class GymConfigEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    @Json(name = "id")
    val id: String = "main",

    @ColumnInfo(name = "admin_email")
    @Json(name = "admin_email")
    val admin_email: String = "hema.gym0@gmail.com",

    @ColumnInfo(name = "phone_display")
    @Json(name = "phone_display")
    val phone_display: String = "01039157200",

    @ColumnInfo(name = "whatsapp_intl")
    @Json(name = "whatsapp_intl")
    val whatsapp_intl: String = "201039157200",

    @ColumnInfo(name = "address_ar")
    @Json(name = "address_ar")
    val address_ar: String = "القاهرة - الفرع الرئيسي، برج كابتن هيما جيم، الدور الثاني والثالث",

    @ColumnInfo(name = "working_hours")
    @Json(name = "working_hours")
    val working_hours: String = "يومياً من 8:00 صباحاً حتى 2:00 بعد منتصف الليل (مواعيد مخصصة لقسم السيدات)",

    @ColumnInfo(name = "pkg_1m_price")
    @Json(name = "pkg_1m_price")
    val pkg_1m_price: String = "600",

    @ColumnInfo(name = "pkg_3m_price")
    @Json(name = "pkg_3m_price")
    val pkg_3m_price: String = "1250",

    @ColumnInfo(name = "pkg_6m_price")
    @Json(name = "pkg_6m_price")
    val pkg_6m_price: String = "2000",

    @ColumnInfo(name = "pkg_12m_price")
    @Json(name = "pkg_12m_price")
    val pkg_12m_price: String = "2750",

    @ColumnInfo(name = "tiktok_url")
    @Json(name = "tiktok_url")
    val tiktok_url: String = "https://www.tiktok.com/@captain.hima.gym",

    @ColumnInfo(name = "facebook_page_url")
    @Json(name = "facebook_page_url")
    val facebook_page_url: String = "https://www.facebook.com/captainhimagym",

    @ColumnInfo(name = "instagram_url")
    @Json(name = "instagram_url")
    val instagram_url: String = "https://www.instagram.com/captainhimagym",

    @ColumnInfo(name = "google_maps_url")
    @Json(name = "google_maps_url")
    val google_maps_url: String = "https://maps.google.com/?q=Captain+Hima+Fitness+Gym"
)

data class PackageCatalogItem(
    val packageId: String,
    val titleAr: String,
    val durationMonths: Int,
    val totalDays: Int,
    val freezeDaysAvailable: Int,
    val freeInvitations: Int,
    val defaultPriceEgp: Int
)

object GymDateUtils {
    private val dateFormatter: SimpleDateFormat
        get() = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }

    private val dateTimeArFormatter: SimpleDateFormat
        get() = SimpleDateFormat("yyyy/MM/dd • hh:mm a", Locale("ar"))

    fun formatIsoDate(millis: Long): String = dateFormatter.format(Date(millis))

    fun formatReadableAr(millis: Long): String = dateTimeArFormatter.format(Date(millis))

    fun formatDurationAr(durationMillis: Long): String {
        if (durationMillis <= 0L) return "أقل من دقيقة"
        val totalHours = durationMillis / 3_600_000L
        val days = totalHours / 24
        val hours = totalHours % 24
        val minutes = (durationMillis % 3_600_000L) / 60_000L
        return when {
            days > 0 && hours > 0 -> "$days يوم و $hours ساعة"
            days > 0 -> "$days يوم"
            hours > 0 -> "$hours ساعة و $minutes دقيقة"
            minutes > 0 -> "$minutes دقيقة"
            else -> "ثوانٍ معدودة (تجميد فوري)"
        }
    }

    fun statusArabicLabel(statusCode: String): String = when (statusCode) {
        "PENDING" -> "قيد المراجعة والانتظار"
        "ACTIVE" -> "نشط ومفعل"
        "FROZEN" -> "مجمد مؤقتاً"
        "EXPIRED" -> "منتهي الصلاحية"
        "REJECTED" -> "مرفوض"
        "CANCELLED" -> "ملغي"
        else -> statusCode
    }

    fun generateRandomMemberCode(): String {
        val digits = (1000..9999).random()
        val letter = ('A'..'Z').random()
        return "KH${digits}${letter}"
    }

    fun generateOrderNumber(): String {
        val digits = (100000..999999).random()
        return "ORD-$digits"
    }
}
