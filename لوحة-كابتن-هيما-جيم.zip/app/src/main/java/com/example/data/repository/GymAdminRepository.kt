package com.example.data.repository

import com.example.data.local.GymDao
import com.example.data.model.BookingEntity
import com.example.data.model.GymConfigEntity
import com.example.data.model.GymDateUtils
import com.example.data.model.NotificationEntity
import com.example.data.model.PackageCatalogItem
import com.example.data.model.StoryEntity
import com.example.data.model.SubscriptionEntity
import com.example.data.remote.SupabaseService
import com.example.data.remote.SupabaseSyncStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.max

class GymAdminRepository(
    private val dao: GymDao,
    private val supabase: SupabaseService
) {
    val subscriptionsFlow: Flow<List<SubscriptionEntity>> = dao.observeSubscriptions()
    val bookingsFlow: Flow<List<BookingEntity>> = dao.observeBookings()
    val storiesFlow: Flow<List<StoryEntity>> = dao.observeStories()
    val notificationsFlow: Flow<List<NotificationEntity>> = dao.observeNotifications()
    val gymConfigFlow: Flow<GymConfigEntity?> = dao.observeGymConfig()

    private val _syncStatus = MutableStateFlow(
        SupabaseSyncStatus(
            isConfigured = supabase.isConfigured(),
            isConnected = false,
            statusMessageAr = if (supabase.isConfigured()) {
                "جاهز للمزامنة المباشرة مع Supabase"
            } else {
                "وضع المزامنة المحلية النشط (أضف SUPABASE_URL و SUPABASE_ANON_KEY في Secrets للربط السحابي)"
            }
        )
    )
    val syncStatus: StateFlow<SupabaseSyncStatus> = _syncStatus.asStateFlow()

    fun updateRuntimeSupabaseCredentials(url: String, anonKey: String) {
        supabase.setRuntimeCredentials(url, anonKey)
    }

    fun getEffectiveSupabaseUrl(): String = supabase.effectiveUrl

    suspend fun uploadGalleryMedia(
        context: android.content.Context,
        uri: android.net.Uri
    ): Result<String> {
        return supabase.uploadMediaFile(context, uri)
    }

    /**
     * Pulls latest records from Supabase (if configured) and merges them into Room,
     * and pushes local gym_config if remote is empty.
     */
    suspend fun syncWithSupabase(): Boolean {
        if (!supabase.isConfigured()) {
            _syncStatus.value = SupabaseSyncStatus(
                isConfigured = false,
                isConnected = false,
                statusMessageAr = "بانتظار إدخال SUPABASE_URL و SUPABASE_ANON_KEY للربط الفوري بتطبيق العميل",
                activeProjectUrl = ""
            )
            return false
        }

        var anySuccess = false
        var lastError = ""
        supabase.fetchSubscriptions()
            .onSuccess { list ->
                if (list.isNotEmpty()) dao.upsertSubscriptions(list)
                anySuccess = true
            }
            .onFailure { lastError = it.message.orEmpty() }

        supabase.fetchBookings()
            .onSuccess { list ->
                if (list.isNotEmpty()) dao.upsertBookings(list)
                anySuccess = true
            }

        supabase.fetchStories()
            .onSuccess { list ->
                if (list.isNotEmpty()) dao.upsertStories(list)
                anySuccess = true
            }

        supabase.fetchNotifications()
            .onSuccess { list ->
                if (list.isNotEmpty()) dao.upsertNotifications(list)
                anySuccess = true
            }

        supabase.fetchGymConfig()
            .onSuccess { config ->
                if (config != null) {
                    dao.upsertGymConfig(config)
                } else {
                    dao.getGymConfigOnce()?.let { supabase.upsertGymConfig(it) }
                }
                anySuccess = true
            }

        val now = System.currentTimeMillis()
        _syncStatus.value = if (anySuccess) {
            SupabaseSyncStatus(
                isConfigured = true,
                isConnected = true,
                statusMessageAr = "متصل ومربوط لحظياً مع تطبيق العميل عبر Supabase Cloud",
                activeProjectUrl = supabase.effectiveUrl,
                lastSyncMillis = now
            )
        } else {
            SupabaseSyncStatus(
                isConfigured = true,
                isConnected = false,
                statusMessageAr = "تعذر الاتصال بـ Supabase ($lastError) — تأكد من صحة SUPABASE_URL والمفتاح",
                activeProjectUrl = supabase.effectiveUrl,
                lastSyncMillis = now
            )
        }
        return anySuccess
    }

    /**
     * 1) قبول وتفعيل (Approve):
     * - يحول status_code إلى 'ACTIVE'
     * - يضبط activated_at_utc_millis على الوقت الحالي Date.now()
     * - يحسب expires_at_utc_millis = Date.now() + (total_days * 86400000)
     * - يرسل إشعاراً تلقائياً في جدول notifications بنوع 'ACTIVATED' لهذا الكود
     */
    suspend fun approveSubscription(subscription: SubscriptionEntity): SubscriptionEntity {
        val now = System.currentTimeMillis()
        val expiresAt = now + (subscription.total_days.toLong() * 86_400_000L)
        val updated = subscription.copy(
            status_code = "ACTIVE",
            status_ar = "نشط ومفعل",
            activated_at_utc_millis = now,
            expires_at_utc_millis = expiresAt,
            frozen_at_utc_millis = null,
            remaining_days = subscription.total_days,
            start_date = GymDateUtils.formatIsoDate(now),
            end_date = GymDateUtils.formatIsoDate(expiresAt)
        )
        dao.upsertSubscription(updated)
        supabase.upsertSubscription(updated)

        val autoNotification = NotificationEntity(
            id = "notif_${now}",
            title = "تم تفعيل اشتراكك بنجاح #${updated.code}",
            message = "مرحباً ${updated.full_name}! تم تفعيل (${updated.package_title}) في نادي كابتن هيما جيم. صلاحية الاشتراك حتى ${updated.end_date}.",
            type = "ACTIVATED",
            target_code = updated.code,
            is_read = false,
            created_at_utc_millis = now
        )
        dao.upsertNotification(autoNotification)
        supabase.upsertNotification(autoNotification)

        return updated
    }

    /**
     * 2) رفض الطلب (Reject):
     * - يحول status_code إلى 'REJECTED'
     */
    suspend fun rejectSubscription(subscription: SubscriptionEntity): SubscriptionEntity {
        val updated = subscription.copy(
            status_code = "REJECTED",
            status_ar = "مرفوض",
            remaining_days = 0
        )
        dao.upsertSubscription(updated)
        supabase.upsertSubscription(updated)
        return updated
    }

    /**
     * 3) تجميد / فك تجميد الاشتراك (Freeze / Unfreeze):
     * - عند التجميد: يتحقق من توفر رصيد أيام التجميد (freeze_days_available > 0)، يحول status_code إلى 'FROZEN'،
     *   يحفظ frozen_at_utc_millis = Date.now()، ويوقف عداد remaining_days في تطبيق العميل.
     * - عند فك التجميد: يحسب مدة التجميد (Date.now() - frozen_at_utc_millis)، يضيفها إلى expires_at_utc_millis
     *   و accumulated_freeze_millis، يخصم أيام التجميد المستهلكة من freeze_days_available،
     *   ويعيد الحالة إلى 'ACTIVE' ليستأنف عداد remaining_days.
     */
    suspend fun toggleFreezeSubscription(
        subscription: SubscriptionEntity,
        nowMillis: Long = System.currentTimeMillis()
    ): Result<SubscriptionEntity> {
        return if (subscription.status_code == "FROZEN") {
            unfreezeSubscription(subscription, nowMillis)
        } else {
            freezeSubscription(subscription, nowMillis)
        }
    }

    suspend fun freezeSubscription(
        subscription: SubscriptionEntity,
        nowMillis: Long = System.currentTimeMillis()
    ): Result<SubscriptionEntity> {
        if (subscription.status_code != "ACTIVE") {
            return Result.failure(IllegalStateException("لا يمكن تجميد اشتراك غير نشط"))
        }
        if (subscription.freeze_days_available <= 0) {
            return Result.failure(
                IllegalStateException("لا توجد أيام تجميد متاحة لهذا المشترك (الرصيد المتاح: 0 يوم). يمكنك إضافة رصيد تجميد أولاً.")
            )
        }

        val updated = subscription.freezeAt(nowMillis)
        dao.upsertSubscription(updated)
        supabase.upsertSubscription(updated)
        return Result.success(updated)
    }

    suspend fun unfreezeSubscription(
        subscription: SubscriptionEntity,
        nowMillis: Long = System.currentTimeMillis()
    ): Result<SubscriptionEntity> {
        if (subscription.status_code != "FROZEN") {
            return Result.failure(IllegalStateException("الاشتراك ليس في حالة تجميد حالياً"))
        }

        val updated = subscription.unfreezeAt(nowMillis)
        dao.upsertSubscription(updated)
        supabase.upsertSubscription(updated)
        return Result.success(updated)
    }

    /**
     * تعديل رصيد أيام التجميد المتاحة (freeze_days_available) للمشترك
     */
    suspend fun updateFreezeDaysAvailable(
        subscription: SubscriptionEntity,
        newFreezeDaysAvailable: Int
    ): SubscriptionEntity {
        val updated = subscription.copy(
            freeze_days_available = max(0, newFreezeDaysAvailable)
        )
        dao.upsertSubscription(updated)
        supabase.upsertSubscription(updated)
        return updated
    }

    /**
     * 4) تمديد الاشتراك (+ أيام إضافية):
     * إضافة 7 أو 15 أو 30 أو 90 يوماً إلى expires_at_utc_millis و total_days.
     */
    suspend fun extendSubscriptionDays(subscription: SubscriptionEntity, extraDays: Int): SubscriptionEntity {
        val now = System.currentTimeMillis()
        val extraMillis = extraDays.toLong() * 86_400_000L
        val currentExpires = subscription.expires_at_utc_millis?.let { max(now, it) } ?: (now + extraMillis)
        val newExpires = if (subscription.expires_at_utc_millis != null) {
            currentExpires + extraMillis
        } else {
            now + ((subscription.total_days + extraDays).toLong() * 86_400_000L)
        }
        val newTotalDays = subscription.total_days + extraDays
        val newRemainingDays = subscription.computeLiveRemainingDays(now) + extraDays
        val newStatus = if (subscription.status_code == "EXPIRED") "ACTIVE" else subscription.status_code

        val updated = subscription.copy(
            total_days = newTotalDays,
            remaining_days = newRemainingDays,
            expires_at_utc_millis = newExpires,
            end_date = GymDateUtils.formatIsoDate(newExpires),
            status_code = newStatus,
            status_ar = GymDateUtils.statusArabicLabel(newStatus)
        )
        dao.upsertSubscription(updated)
        supabase.upsertSubscription(updated)
        return updated
    }

    /**
     * 5) إضافة مشترك جديد وتوليد كود عشوائي فوري (#KH...) وتفعيله فوراً
     */
    suspend fun createNewMemberSubscription(
        code: String,
        fullName: String,
        phone: String,
        genderCategory: String,
        pkg: PackageCatalogItem,
        pricePaidEgp: Int,
        activateImmediately: Boolean
    ): SubscriptionEntity {
        val now = System.currentTimeMillis()
        val expiresAt = now + (pkg.totalDays.toLong() * 86_400_000L)
        val cleanCode = code.trim().uppercase().removePrefix("#")

        val newSub = SubscriptionEntity(
            code = cleanCode,
            order_number = GymDateUtils.generateOrderNumber(),
            full_name = fullName.trim(),
            phone = phone.trim(),
            gender_category = genderCategory,
            package_id = pkg.packageId,
            package_title = pkg.titleAr,
            price_paid_egp = pricePaidEgp,
            duration_months = pkg.durationMonths,
            total_days = pkg.totalDays,
            remaining_days = pkg.totalDays,
            start_date = GymDateUtils.formatIsoDate(now),
            end_date = GymDateUtils.formatIsoDate(expiresAt),
            status_code = if (activateImmediately) "ACTIVE" else "PENDING",
            status_ar = if (activateImmediately) "نشط ومفعل" else "قيد المراجعة والانتظار",
            created_at_utc_millis = now,
            activated_at_utc_millis = if (activateImmediately) now else null,
            expires_at_utc_millis = if (activateImmediately) expiresAt else null,
            frozen_at_utc_millis = null,
            accumulated_freeze_millis = 0L,
            freeze_days_available = pkg.freezeDaysAvailable,
            free_invitations_left = pkg.freeInvitations
        )

        dao.upsertSubscription(newSub)
        supabase.upsertSubscription(newSub)

        if (activateImmediately) {
            val autoNotification = NotificationEntity(
                id = "notif_${now}",
                title = "مرحباً بك في كابتن هيما جيم #${newSub.code}",
                message = "تم إصدار وتفعيل عضويتك (${newSub.package_title}) بنجاح. كود الدخول الخاص بك: #${newSub.code} وصالح حتى ${newSub.end_date}.",
                type = "ACTIVATED",
                target_code = newSub.code,
                is_read = false,
                created_at_utc_millis = now
            )
            dao.upsertNotification(autoNotification)
            supabase.upsertNotification(autoNotification)
        }

        return newSub
    }

    suspend fun decrementInvitation(subscription: SubscriptionEntity): SubscriptionEntity {
        val updated = subscription.copy(
            free_invitations_left = max(0, subscription.free_invitations_left - 1)
        )
        dao.upsertSubscription(updated)
        supabase.upsertSubscription(updated)
        return updated
    }

    suspend fun deleteSubscription(code: String) {
        dao.deleteSubscription(code)
        supabase.deleteSubscription(code)
    }

    suspend fun findSubscriptionByCode(code: String): SubscriptionEntity? {
        val normalized = code.trim().removePrefix("#").uppercase()
        return dao.getSubscriptionByCode(normalized)
    }

    // --- Bookings ---
    suspend fun updateBookingStatus(booking: BookingEntity, newStatus: String) {
        val updated = booking.copy(status = newStatus)
        dao.upsertBooking(updated)
        supabase.upsertBooking(updated)
    }

    suspend fun deleteBooking(id: String) {
        dao.deleteBooking(id)
        supabase.deleteBooking(id)
    }

    // --- Stories ---
    suspend fun saveStory(story: StoryEntity) {
        dao.upsertStory(story)
        supabase.upsertStory(story)
    }

    suspend fun toggleStoryActive(story: StoryEntity) {
        val updated = story.copy(is_active = !story.is_active)
        dao.upsertStory(updated)
        supabase.upsertStory(updated)
    }

    suspend fun deleteStory(id: String) {
        dao.deleteStory(id)
        supabase.deleteStory(id)
    }

    // --- Notifications ---
    suspend fun saveNotification(notification: NotificationEntity) {
        dao.upsertNotification(notification)
        supabase.upsertNotification(notification)
    }

    suspend fun deleteNotification(id: String) {
        dao.deleteNotification(id)
        supabase.deleteNotification(id)
    }

    // --- Gym Config ---
    suspend fun saveGymConfig(config: GymConfigEntity) {
        val mainConfig = config.copy(id = "main")
        dao.upsertGymConfig(mainConfig)
        supabase.upsertGymConfig(mainConfig)
    }

    fun getPackageCatalog(config: GymConfigEntity?): List<PackageCatalogItem> {
        val p1 = config?.pkg_1m_price?.toIntOrNull() ?: 600
        val p3 = config?.pkg_3m_price?.toIntOrNull() ?: 1250
        val p6 = config?.pkg_6m_price?.toIntOrNull() ?: 2000
        val p12 = config?.pkg_12m_price?.toIntOrNull() ?: 2750

        return listOf(
            PackageCatalogItem(
                packageId = "pkg_1m",
                titleAr = "باقة شهر واحد - فتنس وكارديو",
                durationMonths = 1,
                totalDays = 30,
                freezeDaysAvailable = 7,
                freeInvitations = 2,
                defaultPriceEgp = p1
            ),
            PackageCatalogItem(
                packageId = "pkg_3m",
                titleAr = "باقة 3 شهور - وحوش الحديد",
                durationMonths = 3,
                totalDays = 90,
                freezeDaysAvailable = 15,
                freeInvitations = 4,
                defaultPriceEgp = p3
            ),
            PackageCatalogItem(
                packageId = "pkg_6m",
                titleAr = "باقة 6 شهور بريميوم + سبا",
                durationMonths = 6,
                totalDays = 180,
                freezeDaysAvailable = 30,
                freeInvitations = 6,
                defaultPriceEgp = p6
            ),
            PackageCatalogItem(
                packageId = "pkg_12m",
                titleAr = "باقة سنة VIP الملكية الشاملة",
                durationMonths = 12,
                totalDays = 360,
                freezeDaysAvailable = 45,
                freeInvitations = 10,
                defaultPriceEgp = p12
            )
        )
    }
}
