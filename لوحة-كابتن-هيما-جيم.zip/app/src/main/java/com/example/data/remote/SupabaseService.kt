package com.example.data.remote

import android.content.Context
import android.net.Uri
import com.example.BuildConfig
import com.example.data.model.BookingEntity
import com.example.data.model.GymConfigEntity
import com.example.data.model.GymDateUtils
import com.example.data.model.NotificationEntity
import com.example.data.model.StoryEntity
import com.example.data.model.SubscriptionEntity
import java.io.File
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject

data class SupabaseSyncStatus(
    val isConfigured: Boolean,
    val isConnected: Boolean,
    val statusMessageAr: String,
    val activeProjectUrl: String = "",
    val lastSyncMillis: Long? = null
)

/**
 * Resilient Supabase PostgREST client that handles:
 * - BuildConfig (Secrets panel) + Runtime DataStore credentials
 * - Automatic URL normalization (adds https:// or .supabase.co if needed)
 * - Automatic header negotiation (works with legacy JWT `eyJ...`, `sb_publishable_...`, and `sb_secret_...`)
 * - Lenient JSON parsing via org.json so nullable columns or numeric/string Postgres column types never fail
 */
class SupabaseService {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    @Volatile
    private var overrideUrl: String = ""

    @Volatile
    private var overrideAnonKey: String = ""

    fun setRuntimeCredentials(url: String, anonKey: String) {
        overrideUrl = normalizeSupabaseUrl(url)
        overrideAnonKey = anonKey.trim()
    }

    private fun normalizeSupabaseUrl(raw: String): String {
        val trimmed = raw.trim().trimEnd('/')
        if (trimmed.isEmpty() || trimmed.contains("your-project-id")) return ""
        val withScheme = when {
            trimmed.startsWith("https://") -> trimmed
            trimmed.startsWith("http://") -> "https://" + trimmed.removePrefix("http://")
            else -> "https://$trimmed"
        }
        // If user entered only the project ref ID (no dots), append .supabase.co
        val hostPart = withScheme.removePrefix("https://").substringBefore("/")
        return if (!hostPart.contains(".")) {
            "https://$hostPart.supabase.co"
        } else {
            "https://$hostPart"
        }
    }

    val effectiveUrl: String
        get() {
            if (overrideUrl.isNotEmpty()) return overrideUrl
            val fromBuildConfig = runCatching { BuildConfig.SUPABASE_URL }.getOrDefault("")
            return normalizeSupabaseUrl(fromBuildConfig)
        }

    val effectiveAnonKey: String
        get() {
            if (overrideAnonKey.isNotEmpty()) return overrideAnonKey
            val fromBuildConfig = runCatching { BuildConfig.SUPABASE_ANON_KEY.trim() }.getOrDefault("")
            return if (fromBuildConfig == "YOUR_SUPABASE_ANON_KEY") "" else fromBuildConfig
        }

    fun isConfigured(): Boolean {
        return effectiveUrl.startsWith("https://") && effectiveAnonKey.isNotEmpty()
    }

    /**
     * Executes a PostgREST request with smart header negotiation:
     * Tries with both `apikey` and `Authorization: Bearer` first, and if 401/403 occurs
     * (e.g. with opaque `sb_publishable_` keys on newer gateways), automatically retries with `apikey` only.
     */
    private fun executeRestCall(
        pathAndQuery: String,
        method: String = "GET",
        body: RequestBody? = null,
        preferHeader: String? = null
    ): Response {
        val url = "${effectiveUrl}/rest/v1/${pathAndQuery.trimStart('/')}"
        val key = effectiveAnonKey

        fun buildReq(includeBearer: Boolean): Request {
            val builder = Request.Builder()
                .url(url)
                .addHeader("apikey", key)
                .addHeader("Content-Type", "application/json")
            if (includeBearer) {
                builder.addHeader("Authorization", "Bearer $key")
            }
            if (preferHeader != null) {
                builder.addHeader("Prefer", preferHeader)
            }
            when (method) {
                "GET" -> builder.get()
                "POST" -> builder.post(body ?: "{}".toRequestBody(jsonMediaType))
                "PATCH" -> builder.patch(body ?: "{}".toRequestBody(jsonMediaType))
                "DELETE" -> builder.delete()
            }
            return builder.build()
        }

        // First attempt: include Bearer if JWT (`eyJ`), omit if `sb_publishable_` / `sb_secret_`
        val primaryIncludeBearer = key.startsWith("eyJ")
        val firstResp = client.newCall(buildReq(includeBearer = primaryIncludeBearer)).execute()
        if (firstResp.code == 401 || firstResp.code == 403) {
            firstResp.close()
            return client.newCall(buildReq(includeBearer = !primaryIncludeBearer)).execute()
        }
        return firstResp
    }

    // --- Subscriptions ---
    suspend fun fetchSubscriptions(): Result<List<SubscriptionEntity>> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isConfigured()) error("لم يتم ضبط SUPABASE_URL")
            executeRestCall("subscriptions?select=*").use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string().orEmpty().take(120)
                    error("HTTP ${response.code}: $errBody")
                }
                val raw = response.body?.string().orEmpty()
                val arr = JSONArray(raw.ifBlank { "[]" })
                val list = mutableListOf<SubscriptionEntity>()
                val now = System.currentTimeMillis()
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val code = obj.optString("code", "").trim()
                    if (code.isEmpty()) continue
                    val totalDays = obj.optInt("total_days", 30)
                    val statusCode = obj.optString("status_code", "PENDING").ifBlank { "PENDING" }
                    list.add(
                        SubscriptionEntity(
                            code = code,
                            order_number = obj.optString("order_number", "ORD-1000"),
                            full_name = obj.optString("full_name", "مشترك"),
                            phone = obj.optString("phone", ""),
                            gender_category = obj.optString("gender_category", "قسم الرجال").ifBlank { "قسم الرجال" },
                            package_id = obj.optString("package_id", "pkg_1m").ifBlank { "pkg_1m" },
                            package_title = obj.optString("package_title", "باقة شهر واحد").ifBlank { "باقة شهر واحد" },
                            price_paid_egp = obj.optInt("price_paid_egp", 600),
                            duration_months = obj.optInt("duration_months", 1),
                            total_days = totalDays,
                            remaining_days = obj.optInt("remaining_days", totalDays),
                            start_date = obj.optString("start_date", "").ifBlank { GymDateUtils.formatIsoDate(now) },
                            end_date = obj.optString("end_date", "").ifBlank { GymDateUtils.formatIsoDate(now + totalDays * 86_400_000L) },
                            status_code = statusCode,
                            status_ar = obj.optString("status_ar", "").ifBlank { GymDateUtils.statusArabicLabel(statusCode) },
                            created_at_utc_millis = obj.optLong("created_at_utc_millis", now),
                            activated_at_utc_millis = if (obj.isNull("activated_at_utc_millis")) null else obj.optLong("activated_at_utc_millis"),
                            expires_at_utc_millis = if (obj.isNull("expires_at_utc_millis")) null else obj.optLong("expires_at_utc_millis"),
                            frozen_at_utc_millis = if (obj.isNull("frozen_at_utc_millis")) null else obj.optLong("frozen_at_utc_millis"),
                            accumulated_freeze_millis = obj.optLong("accumulated_freeze_millis", 0L),
                            freeze_days_available = obj.optInt("freeze_days_available", 7),
                            free_invitations_left = obj.optInt("free_invitations_left", 2)
                        )
                    )
                }
                list
            }
        }
    }

    suspend fun upsertSubscription(entity: SubscriptionEntity): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isConfigured()) return@runCatching
            val obj = JSONObject().apply {
                put("code", entity.code)
                put("order_number", entity.order_number)
                put("full_name", entity.full_name)
                put("phone", entity.phone)
                put("gender_category", entity.gender_category)
                put("package_id", entity.package_id)
                put("package_title", entity.package_title)
                put("price_paid_egp", entity.price_paid_egp)
                put("duration_months", entity.duration_months)
                put("total_days", entity.total_days)
                put("remaining_days", entity.remaining_days)
                put("start_date", entity.start_date)
                put("end_date", entity.end_date)
                put("status_code", entity.status_code)
                put("status_ar", entity.status_ar)
                put("created_at_utc_millis", entity.created_at_utc_millis)
                put("activated_at_utc_millis", entity.activated_at_utc_millis ?: JSONObject.NULL)
                put("expires_at_utc_millis", entity.expires_at_utc_millis ?: JSONObject.NULL)
                put("frozen_at_utc_millis", entity.frozen_at_utc_millis ?: JSONObject.NULL)
                put("accumulated_freeze_millis", entity.accumulated_freeze_millis)
                put("freeze_days_available", entity.freeze_days_available)
                put("free_invitations_left", entity.free_invitations_left)
            }
            executeRestCall(
                pathAndQuery = "subscriptions?on_conflict=code",
                method = "POST",
                body = obj.toString().toRequestBody(jsonMediaType),
                preferHeader = "resolution=merge-duplicates,return=minimal"
            ).use { response ->
                if (!response.isSuccessful) error("HTTP ${response.code}")
            }
        }
    }

    suspend fun deleteSubscription(code: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isConfigured()) return@runCatching
            executeRestCall("subscriptions?code=eq.$code", method = "DELETE").use { response ->
                if (!response.isSuccessful) error("HTTP ${response.code}")
            }
        }
    }

    // --- Bookings ---
    suspend fun fetchBookings(): Result<List<BookingEntity>> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isConfigured()) error("Supabase not configured")
            executeRestCall("bookings?select=*").use { response ->
                if (!response.isSuccessful) error("HTTP ${response.code}")
                val raw = response.body?.string().orEmpty()
                val arr = JSONArray(raw.ifBlank { "[]" })
                val list = mutableListOf<BookingEntity>()
                val now = System.currentTimeMillis()
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val id = obj.optString("id", "").trim()
                    if (id.isEmpty()) continue
                    list.add(
                        BookingEntity(
                            id = id,
                            order_number = obj.optString("order_number", "ORD-BK"),
                            reference_code = obj.optString("reference_code", ""),
                            full_name = obj.optString("full_name", "عميل"),
                            phone = obj.optString("phone", ""),
                            gender_category = obj.optString("gender_category", "قسم الرجال"),
                            booking_type = obj.optString("booking_type", "حجز حصة جماعية"),
                            selected_item_name = obj.optString("selected_item_name", ""),
                            price_egp = obj.optInt("price_egp", 0),
                            preferred_date_time = obj.optString("preferred_date_time", ""),
                            notes = obj.optString("notes", ""),
                            status = obj.optString("status", "PENDING").ifBlank { "PENDING" },
                            created_at_utc_millis = obj.optLong("created_at_utc_millis", now)
                        )
                    )
                }
                list
            }
        }
    }

    suspend fun upsertBooking(entity: BookingEntity): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isConfigured()) return@runCatching
            val obj = JSONObject().apply {
                put("id", entity.id)
                put("order_number", entity.order_number)
                put("reference_code", entity.reference_code)
                put("full_name", entity.full_name)
                put("phone", entity.phone)
                put("gender_category", entity.gender_category)
                put("booking_type", entity.booking_type)
                put("selected_item_name", entity.selected_item_name)
                put("price_egp", entity.price_egp)
                put("preferred_date_time", entity.preferred_date_time)
                put("notes", entity.notes)
                put("status", entity.status)
                put("created_at_utc_millis", entity.created_at_utc_millis)
            }
            executeRestCall(
                pathAndQuery = "bookings?on_conflict=id",
                method = "POST",
                body = obj.toString().toRequestBody(jsonMediaType),
                preferHeader = "resolution=merge-duplicates,return=minimal"
            ).use { response ->
                if (!response.isSuccessful) error("HTTP ${response.code}")
            }
        }
    }

    suspend fun deleteBooking(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isConfigured()) return@runCatching
            executeRestCall("bookings?id=eq.$id", method = "DELETE").use { response ->
                if (!response.isSuccessful) error("HTTP ${response.code}")
            }
        }
    }

    // --- Stories ---
    suspend fun fetchStories(): Result<List<StoryEntity>> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isConfigured()) error("Supabase not configured")
            executeRestCall("stories?select=*").use { response ->
                if (!response.isSuccessful) error("HTTP ${response.code}")
                val raw = response.body?.string().orEmpty()
                val arr = JSONArray(raw.ifBlank { "[]" })
                val list = mutableListOf<StoryEntity>()
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val id = obj.optString("id", "").trim()
                    if (id.isEmpty()) continue
                    list.add(
                        StoryEntity(
                            id = id,
                            title = obj.optString("title", ""),
                            subtitle = obj.optString("subtitle", ""),
                            badge_text = obj.optString("badge_text", ""),
                            category_tag = obj.optString("category_tag", "صالة الحديد"),
                            program_to_book = obj.optString("program_to_book", ""),
                            booking_type_preset = obj.optString("booking_type_preset", "اشتراك باقة"),
                            gender_preset = obj.optString("gender_preset", "قسم الرجال"),
                            video_url = obj.optString("video_url", ""),
                            audio_track_title = obj.optString("audio_track_title", ""),
                            likes_count = obj.optInt("likes_count", 0),
                            shares_count = obj.optInt("shares_count", 0),
                            sort_order = obj.optInt("sort_order", i + 1),
                            is_active = obj.optBoolean("is_active", true)
                        )
                    )
                }
                list.sortedBy { it.sort_order }
            }
        }
    }

    suspend fun upsertStory(entity: StoryEntity): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isConfigured()) return@runCatching
            val obj = JSONObject().apply {
                put("id", entity.id)
                put("title", entity.title)
                put("subtitle", entity.subtitle)
                put("badge_text", entity.badge_text)
                put("category_tag", entity.category_tag)
                put("program_to_book", entity.program_to_book)
                put("booking_type_preset", entity.booking_type_preset)
                put("gender_preset", entity.gender_preset)
                put("video_url", entity.video_url)
                put("audio_track_title", entity.audio_track_title)
                put("likes_count", entity.likes_count)
                put("shares_count", entity.shares_count)
                put("sort_order", entity.sort_order)
                put("is_active", entity.is_active)
            }
            executeRestCall(
                pathAndQuery = "stories?on_conflict=id",
                method = "POST",
                body = obj.toString().toRequestBody(jsonMediaType),
                preferHeader = "resolution=merge-duplicates,return=minimal"
            ).use { response ->
                if (!response.isSuccessful) error("HTTP ${response.code}")
            }
        }
    }

    suspend fun deleteStory(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isConfigured()) return@runCatching
            executeRestCall("stories?id=eq.$id", method = "DELETE").use { response ->
                if (!response.isSuccessful) error("HTTP ${response.code}")
            }
        }
    }

    // --- Notifications ---
    suspend fun fetchNotifications(): Result<List<NotificationEntity>> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isConfigured()) error("Supabase not configured")
            executeRestCall("notifications?select=*").use { response ->
                if (!response.isSuccessful) error("HTTP ${response.code}")
                val raw = response.body?.string().orEmpty()
                val arr = JSONArray(raw.ifBlank { "[]" })
                val list = mutableListOf<NotificationEntity>()
                val now = System.currentTimeMillis()
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val id = obj.optString("id", "").trim()
                    if (id.isEmpty()) continue
                    list.add(
                        NotificationEntity(
                            id = id,
                            title = obj.optString("title", ""),
                            message = obj.optString("message", ""),
                            type = obj.optString("type", "ANNOUNCEMENT").ifBlank { "ANNOUNCEMENT" },
                            target_code = obj.optString("target_code", "ALL").ifBlank { "ALL" },
                            is_read = obj.optBoolean("is_read", false),
                            created_at_utc_millis = obj.optLong("created_at_utc_millis", now)
                        )
                    )
                }
                list.sortedByDescending { it.created_at_utc_millis }
            }
        }
    }

    suspend fun upsertNotification(entity: NotificationEntity): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isConfigured()) return@runCatching
            val obj = JSONObject().apply {
                put("id", entity.id)
                put("title", entity.title)
                put("message", entity.message)
                put("type", entity.type)
                put("target_code", entity.target_code)
                put("is_read", entity.is_read)
                put("created_at_utc_millis", entity.created_at_utc_millis)
            }
            executeRestCall(
                pathAndQuery = "notifications?on_conflict=id",
                method = "POST",
                body = obj.toString().toRequestBody(jsonMediaType),
                preferHeader = "resolution=merge-duplicates,return=minimal"
            ).use { response ->
                if (!response.isSuccessful) error("HTTP ${response.code}")
            }
        }
    }

    suspend fun deleteNotification(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isConfigured()) return@runCatching
            executeRestCall("notifications?id=eq.$id", method = "DELETE").use { response ->
                if (!response.isSuccessful) error("HTTP ${response.code}")
            }
        }
    }

    // --- Gym Config ---
    suspend fun fetchGymConfig(): Result<GymConfigEntity?> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isConfigured()) error("Supabase not configured")
            executeRestCall("gym_config?id=eq.main&select=*").use { response ->
                if (!response.isSuccessful) error("HTTP ${response.code}")
                val raw = response.body?.string().orEmpty()
                val arr = JSONArray(raw.ifBlank { "[]" })
                if (arr.length() == 0) return@runCatching null
                val obj = arr.optJSONObject(0) ?: return@runCatching null
                GymConfigEntity(
                    id = obj.optString("id", "main").ifBlank { "main" },
                    admin_email = obj.optString("admin_email", "hema.gym0@gmail.com"),
                    phone_display = obj.optString("phone_display", "01039157200"),
                    whatsapp_intl = obj.optString("whatsapp_intl", "201039157200"),
                    address_ar = obj.optString("address_ar", ""),
                    working_hours = obj.optString("working_hours", ""),
                    pkg_1m_price = obj.optString("pkg_1m_price", "600"),
                    pkg_3m_price = obj.optString("pkg_3m_price", "1250"),
                    pkg_6m_price = obj.optString("pkg_6m_price", "2000"),
                    pkg_12m_price = obj.optString("pkg_12m_price", "2750"),
                    tiktok_url = obj.optString("tiktok_url", ""),
                    facebook_page_url = obj.optString("facebook_page_url", ""),
                    instagram_url = obj.optString("instagram_url", ""),
                    google_maps_url = obj.optString("google_maps_url", "")
                )
            }
        }
    }

    suspend fun upsertGymConfig(entity: GymConfigEntity): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isConfigured()) return@runCatching
            val obj = JSONObject().apply {
                put("id", "main")
                put("admin_email", entity.admin_email)
                put("phone_display", entity.phone_display)
                put("whatsapp_intl", entity.whatsapp_intl)
                put("address_ar", entity.address_ar)
                put("working_hours", entity.working_hours)
                put("pkg_1m_price", entity.pkg_1m_price)
                put("pkg_3m_price", entity.pkg_3m_price)
                put("pkg_6m_price", entity.pkg_6m_price)
                put("pkg_12m_price", entity.pkg_12m_price)
                put("tiktok_url", entity.tiktok_url)
                put("facebook_page_url", entity.facebook_page_url)
                put("instagram_url", entity.instagram_url)
                put("google_maps_url", entity.google_maps_url)
            }
            executeRestCall(
                pathAndQuery = "gym_config?on_conflict=id",
                method = "POST",
                body = obj.toString().toRequestBody(jsonMediaType),
                preferHeader = "resolution=merge-duplicates,return=minimal"
            ).use { response ->
                if (!response.isSuccessful) error("HTTP ${response.code}")
            }
        }
    }

    /**
     * Copies a selected gallery image or video (from PickVisualMedia) into local app storage
     * and uploads it to Supabase Storage if configured, returning the public URL (or local URI fallback).
     */
    suspend fun uploadMediaFile(context: Context, uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val contentResolver = context.contentResolver
            val mimeType = contentResolver.getType(uri) ?: "image/jpeg"
            val isVideo = mimeType.contains("video") || uri.toString().contains("video")
            val ext = when {
                isVideo -> "mp4"
                mimeType.contains("png") -> "png"
                mimeType.contains("webp") -> "webp"
                else -> "jpg"
            }
            val fileName = "gym_media_${System.currentTimeMillis()}.$ext"
            val mediaDir = File(context.filesDir, "gym_media").apply { mkdirs() }
            val localFile = File(mediaDir, fileName)

            contentResolver.openInputStream(uri)?.use { input ->
                localFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: error("تعذر قراءة الملف المختار من المعرض")

            if (isConfigured()) {
                val key = effectiveAnonKey
                runCatching {
                    val bucketJson = """{"id":"media","name":"media","public":true}"""
                    val bucketBuilder = Request.Builder()
                        .url("${effectiveUrl}/storage/v1/bucket")
                        .addHeader("apikey", key)
                        .addHeader("Content-Type", "application/json")
                    if (key.startsWith("eyJ")) {
                        bucketBuilder.addHeader("Authorization", "Bearer $key")
                    }
                    client.newCall(
                        bucketBuilder.post(bucketJson.toRequestBody(jsonMediaType)).build()
                    ).execute().close()
                }

                val fileBytes = localFile.readBytes()
                for (bucket in listOf("media", "stories", "public")) {
                    val reqBuilder = Request.Builder()
                        .url("${effectiveUrl}/storage/v1/object/$bucket/$fileName")
                        .addHeader("apikey", key)
                        .addHeader("Content-Type", mimeType)
                        .addHeader("x-upsert", "true")
                    if (key.startsWith("eyJ")) {
                        reqBuilder.addHeader("Authorization", "Bearer $key")
                    }
                    val req = reqBuilder
                        .post(fileBytes.toRequestBody(mimeType.toMediaType()))
                        .build()

                    val uploadedPublicUrl = runCatching {
                        client.newCall(req).execute().use { resp ->
                            if (resp.isSuccessful) {
                                "${effectiveUrl}/storage/v1/object/public/$bucket/$fileName"
                            } else null
                        }
                    }.getOrNull()

                    if (uploadedPublicUrl != null) {
                        return@runCatching uploadedPublicUrl
                    }
                }
            }

            Uri.fromFile(localFile).toString()
        }
    }
}
