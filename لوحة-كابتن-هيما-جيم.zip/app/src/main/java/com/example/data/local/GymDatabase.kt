package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.BookingEntity
import com.example.data.model.GymConfigEntity
import com.example.data.model.GymDateUtils
import com.example.data.model.NotificationEntity
import com.example.data.model.StoryEntity
import com.example.data.model.SubscriptionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface GymDao {
    // --- Subscriptions ---
    @Query("SELECT * FROM subscriptions ORDER BY CASE status_code WHEN 'PENDING' THEN 0 WHEN 'ACTIVE' THEN 1 WHEN 'FROZEN' THEN 2 ELSE 3 END, created_at_utc_millis DESC")
    fun observeSubscriptions(): Flow<List<SubscriptionEntity>>

    @Query("SELECT * FROM subscriptions WHERE UPPER(code) = UPPER(:code) LIMIT 1")
    suspend fun getSubscriptionByCode(code: String): SubscriptionEntity?

    @Query("SELECT COUNT(*) FROM subscriptions")
    suspend fun getSubscriptionsCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSubscription(subscription: SubscriptionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSubscriptions(subscriptions: List<SubscriptionEntity>)

    @Query("DELETE FROM subscriptions WHERE code = :code")
    suspend fun deleteSubscription(code: String)

    // --- Bookings ---
    @Query("SELECT * FROM bookings ORDER BY CASE status WHEN 'PENDING' THEN 0 WHEN 'ACTIVE' THEN 1 ELSE 2 END, created_at_utc_millis DESC")
    fun observeBookings(): Flow<List<BookingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBooking(booking: BookingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBookings(bookings: List<BookingEntity>)

    @Query("DELETE FROM bookings WHERE id = :id")
    suspend fun deleteBooking(id: String)

    // --- Stories ---
    @Query("SELECT * FROM stories ORDER BY sort_order ASC")
    fun observeStories(): Flow<List<StoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStory(story: StoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStories(stories: List<StoryEntity>)

    @Query("DELETE FROM stories WHERE id = :id")
    suspend fun deleteStory(id: String)

    // --- Notifications ---
    @Query("SELECT * FROM notifications ORDER BY created_at_utc_millis DESC")
    fun observeNotifications(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNotification(notification: NotificationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNotifications(notifications: List<NotificationEntity>)

    @Query("DELETE FROM notifications WHERE id = :id")
    suspend fun deleteNotification(id: String)

    // --- Gym Config ---
    @Query("SELECT * FROM gym_config WHERE id = 'main' LIMIT 1")
    fun observeGymConfig(): Flow<GymConfigEntity?>

    @Query("SELECT * FROM gym_config WHERE id = 'main' LIMIT 1")
    suspend fun getGymConfigOnce(): GymConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertGymConfig(config: GymConfigEntity)
}

@Database(
    entities = [
        SubscriptionEntity::class,
        BookingEntity::class,
        StoryEntity::class,
        NotificationEntity::class,
        GymConfigEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class GymDatabase : RoomDatabase() {
    abstract fun gymDao(): GymDao

    companion object {
        @Volatile
        private var INSTANCE: GymDatabase? = null

        fun getInstance(context: Context): GymDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GymDatabase::class.java,
                    "captain_hima_gym_admin.db"
                ).fallbackToDestructiveMigration(dropAllTables = true).build()
                INSTANCE = instance
                instance
            }
        }

        suspend fun ensureSeeded(dao: GymDao) {
            if (dao.getGymConfigOnce() == null) {
                dao.upsertGymConfig(GymConfigEntity(id = "main"))
            }
            if (dao.getSubscriptionsCount() == 0) {
                val now = System.currentTimeMillis()
                val dayMillis = 86_400_000L

                val initialSubscriptions = listOf(
                    SubscriptionEntity(
                        code = "KH8492A",
                        order_number = "ORD-294810",
                        full_name = "أحمد محمود الشناوي",
                        phone = "01012345678",
                        gender_category = "قسم الرجال",
                        package_id = "pkg_3m",
                        package_title = "باقة 3 شهور - وحوش الحديد",
                        price_paid_egp = 1250,
                        duration_months = 3,
                        total_days = 90,
                        remaining_days = 90,
                        start_date = GymDateUtils.formatIsoDate(now),
                        end_date = GymDateUtils.formatIsoDate(now + 90 * dayMillis),
                        status_code = "PENDING",
                        status_ar = "قيد المراجعة والانتظار",
                        created_at_utc_millis = now - (2 * 3600_000L),
                        activated_at_utc_millis = null,
                        expires_at_utc_millis = null,
                        frozen_at_utc_millis = null,
                        accumulated_freeze_millis = 0L,
                        freeze_days_available = 15,
                        free_invitations_left = 4
                    ),
                    SubscriptionEntity(
                        code = "KH5109M",
                        order_number = "ORD-294855",
                        full_name = "مريم طارق عبد العزيز",
                        phone = "01129876543",
                        gender_category = "قسم السيدات",
                        package_id = "pkg_6m",
                        package_title = "باقة 6 شهور بريميوم + سبا",
                        price_paid_egp = 2000,
                        duration_months = 6,
                        total_days = 180,
                        remaining_days = 180,
                        start_date = GymDateUtils.formatIsoDate(now),
                        end_date = GymDateUtils.formatIsoDate(now + 180 * dayMillis),
                        status_code = "PENDING",
                        status_ar = "قيد المراجعة والانتظار",
                        created_at_utc_millis = now - (45 * 60_000L),
                        activated_at_utc_millis = null,
                        expires_at_utc_millis = null,
                        frozen_at_utc_millis = null,
                        accumulated_freeze_millis = 0L,
                        freeze_days_available = 30,
                        free_invitations_left = 6
                    ),
                    SubscriptionEntity(
                        code = "KH9921V",
                        order_number = "ORD-291044",
                        full_name = "كريم وائل الدسوقي",
                        phone = "01287654321",
                        gender_category = "قسم الرجال",
                        package_id = "pkg_12m",
                        package_title = "باقة سنة VIP الملكية الشاملة",
                        price_paid_egp = 2750,
                        duration_months = 12,
                        total_days = 360,
                        remaining_days = 342,
                        start_date = GymDateUtils.formatIsoDate(now - 18 * dayMillis),
                        end_date = GymDateUtils.formatIsoDate(now + 342 * dayMillis),
                        status_code = "ACTIVE",
                        status_ar = "نشط ومفعل",
                        created_at_utc_millis = now - 18 * dayMillis,
                        activated_at_utc_millis = now - 18 * dayMillis,
                        expires_at_utc_millis = now + 342 * dayMillis,
                        frozen_at_utc_millis = null,
                        accumulated_freeze_millis = 0L,
                        freeze_days_available = 45,
                        free_invitations_left = 10
                    ),
                    SubscriptionEntity(
                        code = "KH3374S",
                        order_number = "ORD-288310",
                        full_name = "سارة خالد المنيري",
                        phone = "01099887766",
                        gender_category = "قسم السيدات",
                        package_id = "pkg_1m",
                        package_title = "باقة شهر واحد - فتنس وكارديو",
                        price_paid_egp = 600,
                        duration_months = 1,
                        total_days = 30,
                        remaining_days = 21,
                        start_date = GymDateUtils.formatIsoDate(now - 9 * dayMillis),
                        end_date = GymDateUtils.formatIsoDate(now + 21 * dayMillis),
                        status_code = "ACTIVE",
                        status_ar = "نشط ومفعل",
                        created_at_utc_millis = now - 9 * dayMillis,
                        activated_at_utc_millis = now - 9 * dayMillis,
                        expires_at_utc_millis = now + 21 * dayMillis,
                        frozen_at_utc_millis = null,
                        accumulated_freeze_millis = 0L,
                        freeze_days_available = 7,
                        free_invitations_left = 2
                    ),
                    SubscriptionEntity(
                        code = "KH6048F",
                        order_number = "ORD-275912",
                        full_name = "عمر حسام الدين",
                        phone = "01554433221",
                        gender_category = "قسم الرجال",
                        package_id = "pkg_6m",
                        package_title = "باقة 6 شهور بريميوم + سبا",
                        price_paid_egp = 2000,
                        duration_months = 6,
                        total_days = 180,
                        remaining_days = 128,
                        start_date = GymDateUtils.formatIsoDate(now - 55 * dayMillis),
                        end_date = GymDateUtils.formatIsoDate(now + 125 * dayMillis),
                        status_code = "FROZEN",
                        status_ar = "مجمد مؤقتاً",
                        created_at_utc_millis = now - 55 * dayMillis,
                        activated_at_utc_millis = now - 55 * dayMillis,
                        expires_at_utc_millis = now + 125 * dayMillis,
                        frozen_at_utc_millis = now - 3 * dayMillis,
                        accumulated_freeze_millis = 0L,
                        freeze_days_available = 27,
                        free_invitations_left = 5
                    ),
                    SubscriptionEntity(
                        code = "KH1102X",
                        order_number = "ORD-240119",
                        full_name = "محمود سامي الجوهري",
                        phone = "01066554433",
                        gender_category = "قسم الرجال",
                        package_id = "pkg_1m",
                        package_title = "باقة شهر واحد - فتنس وكارديو",
                        price_paid_egp = 600,
                        duration_months = 1,
                        total_days = 30,
                        remaining_days = 0,
                        start_date = GymDateUtils.formatIsoDate(now - 35 * dayMillis),
                        end_date = GymDateUtils.formatIsoDate(now - 5 * dayMillis),
                        status_code = "EXPIRED",
                        status_ar = "منتهي الصلاحية",
                        created_at_utc_millis = now - 35 * dayMillis,
                        activated_at_utc_millis = now - 35 * dayMillis,
                        expires_at_utc_millis = now - 5 * dayMillis,
                        frozen_at_utc_millis = null,
                        accumulated_freeze_millis = 0L,
                        freeze_days_available = 0,
                        free_invitations_left = 0
                    )
                )
                dao.upsertSubscriptions(initialSubscriptions)

                val initialBookings = listOf(
                    BookingEntity(
                        id = "bk_1001",
                        order_number = "ORD-BK901",
                        reference_code = "KH8492A",
                        full_name = "أحمد محمود الشناوي",
                        phone = "01012345678",
                        gender_category = "قسم الرجال",
                        booking_type = "حجز حصة جماعية",
                        selected_item_name = "كروس فيت وحرق دهون مكثف مع كابتن هيما",
                        price_egp = 150,
                        preferred_date_time = "اليوم - 08:30 مساءً",
                        notes = "أول حصة تقييم بدني + InBody مجاني",
                        status = "PENDING",
                        created_at_utc_millis = now - 3600_000L
                    ),
                    BookingEntity(
                        id = "bk_1002",
                        order_number = "ORD-BK902",
                        reference_code = "KH5109M",
                        full_name = "مريم طارق عبد العزيز",
                        phone = "01129876543",
                        gender_category = "قسم السيدات",
                        booking_type = "حجز حصة جماعية",
                        selected_item_name = "زومبا وأيروبكس للسيدات + جلسة جاكوزي",
                        price_egp = 200,
                        preferred_date_time = "غداً - 05:00 مساءً",
                        notes = "يرجى تأكيد الحجز في قاعة السيدات الخاصة",
                        status = "PENDING",
                        created_at_utc_millis = now - 1800_000L
                    ),
                    BookingEntity(
                        id = "bk_1003",
                        order_number = "ORD-BK889",
                        reference_code = "KH9921V",
                        full_name = "كريم وائل الدسوقي",
                        phone = "01287654321",
                        gender_category = "قسم الرجال",
                        booking_type = "اشتراك باقة",
                        selected_item_name = "جلسة استشفاء سبا وساونا وبخار VIP",
                        price_egp = 0,
                        preferred_date_time = "الخميس - 09:00 مساءً",
                        notes = "ضمن مميزات باقة سنة VIP",
                        status = "ACTIVE",
                        created_at_utc_millis = now - 86_400_000L
                    )
                )
                dao.upsertBookings(initialBookings)

                val initialStories = listOf(
                    StoryEntity(
                        id = "story_1",
                        title = "أقوى تجهيزات صالة الحديد في مصر",
                        subtitle = "أحدث أجهزة المطرقة والكابلات الاحترافية مع إضاءة تحفيزية 3D",
                        badge_text = "حصرياً في كابتن هيما جيم",
                        category_tag = "صالة الحديد",
                        program_to_book = "باقة 3 شهور - وحوش الحديد",
                        booking_type_preset = "اشتراك باقة",
                        gender_preset = "قسم الرجال",
                        video_url = "https://assets.mixkit.co/videos/preview/mixkit-man-training-in-the-gym-22854-large.mp4",
                        audio_track_title = "Captain Hima Official Workout Beat",
                        likes_count = 1420,
                        shares_count = 385,
                        sort_order = 1,
                        is_active = true
                    ),
                    StoryEntity(
                        id = "story_2",
                        title = "قسم السيدات المتكامل بخصوصية 100%",
                        subtitle = "مدربات معتمدات، حصص زومبا وكارديو يومية، وأحدث أجهزة النحت والرشاقة",
                        badge_text = "خصوصية تامة للسيدات",
                        category_tag = "قسم السيدات",
                        program_to_book = "باقة 6 شهور بريميوم + سبا",
                        booking_type_preset = "اشتراك باقة",
                        gender_preset = "قسم السيدات",
                        video_url = "https://assets.mixkit.co/videos/preview/mixkit-woman-running-on-treadmill-at-gym-44457-large.mp4",
                        audio_track_title = "Ladies Fitness Energy Mix",
                        likes_count = 980,
                        shares_count = 290,
                        sort_order = 2,
                        is_active = true
                    ),
                    StoryEntity(
                        id = "story_3",
                        title = "السبا والجاكوزي والساونا الملكية",
                        subtitle = "استشفاء عضلي كامل بعد التمرين بأعلى معايير النظافة والرفاهية",
                        badge_text = "استشفاء VIP",
                        category_tag = "السبا والجاكوزي",
                        program_to_book = "باقة سنة VIP الملكية الشاملة",
                        booking_type_preset = "اشتراك باقة",
                        gender_preset = "قسم الرجال",
                        video_url = "https://assets.mixkit.co/videos/preview/mixkit-athlete-resting-after-workout-23421-large.mp4",
                        audio_track_title = "Luxury Spa Ambient Lounge",
                        likes_count = 760,
                        shares_count = 195,
                        sort_order = 3,
                        is_active = true
                    ),
                    StoryEntity(
                        id = "story_4",
                        title = "تحدي الحصص الجماعية والكروس فيت",
                        subtitle = "احرق حتى 800 سعرة حرارية في الحصة الواحدة مع فريق كابتن هيما",
                        badge_text = "حماس بلا حدود",
                        category_tag = "الحصص الجماعية",
                        program_to_book = "كروس فيت وحرق دهون مكثف",
                        booking_type_preset = "حجز حصة جماعية",
                        gender_preset = "قسم الرجال",
                        video_url = "https://assets.mixkit.co/videos/preview/mixkit-group-of-people-exercising-in-a-gym-44449-large.mp4",
                        audio_track_title = "CrossFit Fire Phonk",
                        likes_count = 640,
                        shares_count = 150,
                        sort_order = 4,
                        is_active = true
                    )
                )
                dao.upsertStories(initialStories)

                val initialNotifications = listOf(
                    NotificationEntity(
                        id = "notif_17940001",
                        title = "عرض الخصم الناري 50% على باقات كابتن هيما جيم!",
                        message = "اشترك الآن في باقة السنة VIP بسعر 2750 ج.م فقط بدلاً من 5500 ج.م شاملة السبا والجاكوزي والدعوات المجانية.",
                        type = "PROMO",
                        target_code = "ALL",
                        is_read = false,
                        created_at_utc_millis = now - 7200_000L
                    ),
                    NotificationEntity(
                        id = "notif_17940002",
                        title = "تم تفعيل اشتراكك بنجاح #KH9921V",
                        message = "مرحباً كريم وائل الدسوقي! تم تفعيل باقة سنة VIP الملكية الشاملة في كابتن هيما جيم. نتمنى لك رحلة رياضية قوية!",
                        type = "ACTIVATED",
                        target_code = "KH9921V",
                        is_read = true,
                        created_at_utc_millis = now - 18 * dayMillis
                    ),
                    NotificationEntity(
                        id = "notif_17940003",
                        title = "وصول دفعة جديدة من أجهزة الـ Hammer Strength",
                        message = "يسر إدارة نادي كابتن هيما جيم الإعلان عن تحديث صالة الحديد بأحدث أجهزة الظهر والكتف الأوروبية.",
                        type = "ANNOUNCEMENT",
                        target_code = "ALL",
                        is_read = false,
                        created_at_utc_millis = now - 86_400_000L
                    )
                )
                dao.upsertNotifications(initialNotifications)
            }
        }
    }
}
