package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.GymDateUtils
import com.example.data.model.NotificationEntity
import com.example.data.model.SubscriptionEntity
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.theme.FieryOrange
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusFrozenCyan

private const val MEDIA_TAG_PREFIX = "\n[MEDIA_URL]:"

private fun extractTextAndMedia(rawMessage: String): Pair<String, String?> {
    if (rawMessage.contains(MEDIA_TAG_PREFIX)) {
        val textPart = rawMessage.substringBefore(MEDIA_TAG_PREFIX).trim()
        val mediaPart = rawMessage.substringAfter(MEDIA_TAG_PREFIX).trim().ifEmpty { null }
        return textPart to mediaPart
    }
    return rawMessage to null
}

private fun isPostImageMedia(url: String): Boolean {
    val lower = url.lowercase()
    return lower.endsWith(".jpg") ||
        lower.endsWith(".jpeg") ||
        lower.endsWith(".png") ||
        lower.endsWith(".webp") ||
        lower.contains("image")
}

@Composable
fun NotificationsScreen(
    notifications: List<NotificationEntity>,
    subscriptions: List<SubscriptionEntity>,
    isUploadingMedia: Boolean,
    onUploadGalleryMedia: (Uri, (String) -> Unit) -> Unit,
    onOpenMediaUrl: (String) -> Unit,
    onSendOrUpdateNotification: (
        id: String?,
        title: String,
        message: String,
        type: String,
        targetCode: String
    ) -> Unit,
    onDeleteNotification: (String) -> Unit
) {
    var editingId by remember { mutableStateOf<String?>(null) }
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var attachedMediaUrl by remember { mutableStateOf<String?>(null) }
    var selectedType by remember { mutableStateOf("PROMO") }
    var targetAll by remember { mutableStateOf(true) }
    var customTargetCode by remember { mutableStateOf("") }

    val postGalleryPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onUploadGalleryMedia(uri) { uploadedUrl ->
                attachedMediaUrl = uploadedUrl
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            LuxuryGlassCard(
                highlighted = true,
                modifier = Modifier.testTag("notification_composer_card")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = if (editingId == null) "نشر خبر أو عرض خصم أو منشور جديد"
                        else "تعديل المنشور / الإشعار ($editingId)",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text("نوع المنشور / الإشعار (type):", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "PROMO" to "🔥 عرض خصم (PROMO)",
                        "ANNOUNCEMENT" to "📢 منشور / خبر عام (ANNOUNCEMENT)",
                        "ACTIVATED" to "✅ تفعيل اشتراك (ACTIVATED)"
                    ).forEach { (typeKey, label) ->
                        FilterChip(
                            selected = selectedType == typeKey,
                            onClick = { selectedType = typeKey },
                            label = { Text(label) },
                            modifier = Modifier.testTag("notif_type_$typeKey")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text("المستهدف (target_code):", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = targetAll,
                        onClick = { targetAll = true },
                        label = { Text("جميع مستخدمي التطبيق (ALL)") },
                        modifier = Modifier.testTag("target_all_chip")
                    )
                    FilterChip(
                        selected = !targetAll,
                        onClick = { targetAll = false },
                        label = { Text("مشترك محدد (#KH...)") },
                        modifier = Modifier.testTag("target_specific_chip")
                    )
                }

                if (!targetAll) {
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = customTargetCode,
                        onValueChange = { customTargetCode = it },
                        label = { Text("كود المشترك المستهدف (مثال: KH8492A)") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("notif_target_code_input")
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        subscriptions.take(6).forEach { sub ->
                            FilterChip(
                                selected = customTargetCode.equals(sub.code, ignoreCase = true),
                                onClick = { customTargetCode = sub.code },
                                label = { Text("#${sub.code} (${sub.full_name.substringBefore(" ")})") }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان المنشور أو العرض (title)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("notif_title_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text("نص المنشور أو العرض بالتفصيل (message)") },
                    minLines = 3,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("notif_message_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Gallery Media Attachment Bar for Posts / Notifications
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "إرفاق صورة أو فيديو من المعرض للمنشور:",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    postGalleryPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("pick_post_image_button")
                            ) {
                                Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("صورة من المعرض", style = MaterialTheme.typography.labelMedium)
                            }

                            OutlinedButton(
                                onClick = {
                                    postGalleryPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                    )
                                },
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("pick_post_video_button")
                            ) {
                                Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("فيديو من المعرض", style = MaterialTheme.typography.labelMedium)
                            }
                        }

                        if (isUploadingMedia) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Text(
                                    text = "جاري إرفاق ورفع الوسائط من المعرض...",
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }

                        if (!attachedMediaUrl.isNullOrBlank()) {
                            val currentMedia = attachedMediaUrl!!
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, StatusActiveGreen)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Collections,
                                                contentDescription = null,
                                                tint = StatusActiveGreen,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Text(
                                                text = if (isPostImageMedia(currentMedia)) "تم إرفاق صورة للمنشور" else "تم إرفاق فيديو للمنشور",
                                                style = MaterialTheme.typography.labelLarge,
                                                color = StatusActiveGreen
                                            )
                                        }
                                        IconButton(
                                            onClick = { attachedMediaUrl = null },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = "إزالة المرفق", modifier = Modifier.size(16.dp))
                                        }
                                    }

                                    if (isPostImageMedia(currentMedia)) {
                                        AsyncImage(
                                            model = currentMedia,
                                            contentDescription = "معاينة صورة المنشور",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(140.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (editingId != null) {
                        OutlinedButton(
                            onClick = {
                                editingId = null
                                title = ""
                                message = ""
                                attachedMediaUrl = null
                                targetAll = true
                                customTargetCode = ""
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إلغاء التعديل")
                        }
                    }

                    Button(
                        onClick = {
                            if (title.isNotBlank() && message.isNotBlank()) {
                                val target = if (targetAll) "ALL" else customTargetCode.ifBlank { "ALL" }
                                val finalMessage = if (!attachedMediaUrl.isNullOrBlank()) {
                                    "${message.trim()}${MEDIA_TAG_PREFIX}${attachedMediaUrl!!.trim()}"
                                } else {
                                    message.trim()
                                }
                                onSendOrUpdateNotification(
                                    editingId,
                                    title,
                                    finalMessage,
                                    selectedType,
                                    target
                                )
                                editingId = null
                                title = ""
                                message = ""
                                attachedMediaUrl = null
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1.6f)
                            .height(48.dp)
                            .testTag("send_notification_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (editingId == null) "نشر وإرسال المنشور فوراً" else "حفظ التعديلات",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "سجل المنشورات والأخبار والعروض المرسلة (${notifications.size})",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        items(notifications, key = { it.id }) { notif ->
            val (cleanText, mediaUrl) = extractTextAndMedia(notif.message)
            val badgeColor = when (notif.type) {
                "PROMO" -> FieryOrange
                "ACTIVATED" -> StatusActiveGreen
                else -> StatusFrozenCyan
            }
            val typeIcon = when (notif.type) {
                "PROMO" -> Icons.Default.LocalOffer
                "ACTIVATED" -> Icons.Default.CheckCircle
                else -> Icons.Default.Campaign
            }

            LuxuryGlassCard(
                accentColor = badgeColor,
                modifier = Modifier.testTag("notification_card_${notif.id}")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = badgeColor.copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, badgeColor)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(typeIcon, contentDescription = null, tint = badgeColor, modifier = Modifier.size(14.dp))
                                Text(
                                    text = notif.type,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = badgeColor,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MetallicGold.copy(alpha = 0.14f)
                        ) {
                            Text(
                                text = if (notif.target_code == "ALL") "للجميع (ALL)" else "كود #${notif.target_code}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MetallicGold,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Row {
                        IconButton(
                            onClick = {
                                val (extractedBody, extractedMedia) = extractTextAndMedia(notif.message)
                                editingId = notif.id
                                title = notif.title
                                message = extractedBody
                                attachedMediaUrl = extractedMedia
                                selectedType = notif.type
                                targetAll = notif.target_code == "ALL"
                                customTargetCode = if (notif.target_code == "ALL") "" else notif.target_code
                            },
                            modifier = Modifier.testTag("edit_notif_${notif.id}")
                        ) {
                            Icon(
                                Icons.Default.Edit,
                                contentDescription = "تعديل الخبر",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(
                            onClick = { onDeleteNotification(notif.id) },
                            modifier = Modifier.testTag("delete_notif_${notif.id}")
                        ) {
                            Icon(
                                Icons.Default.DeleteOutline,
                                contentDescription = "حذف الخبر",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = notif.title,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = cleanText,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (!mediaUrl.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    if (isPostImageMedia(mediaUrl)) {
                        AsyncImage(
                            model = mediaUrl,
                            contentDescription = notif.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(170.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                    } else {
                        OutlinedButton(
                            onClick = { onOpenMediaUrl(mediaUrl) },
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.PlayCircleFilled, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تشغيل الفيديو المرفق بالمنشور")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "تاريخ الإرسال: ${GymDateUtils.formatReadableAr(notif.created_at_utc_millis)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f)
                )
            }
        }

        item { Spacer(modifier = Modifier.height(88.dp)) }
    }
}
