package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.remote.SupabaseSyncStatus
import com.example.ui.theme.FieryOrange
import com.example.ui.theme.FieryOrangeGlow
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusExpiredRed
import com.example.ui.theme.StatusFrozenCyan
import com.example.ui.theme.StatusPendingAmber
import com.example.ui.theme.StatusRejectedRose
import com.example.ui.viewmodel.LiveGymStats

/**
 * 3D Glass Luxury Card with subtle metallic/neon rim border and depth shadow.
 */
@Composable
fun LuxuryGlassCard(
    modifier: Modifier = Modifier,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    highlighted: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val borderBrush = if (highlighted) {
        Brush.linearGradient(
            colors = listOf(
                accentColor.copy(alpha = 0.85f),
                accentColor.copy(alpha = 0.25f),
                MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
            )
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                MaterialTheme.colorScheme.outline.copy(alpha = 0.75f),
                MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
            )
        )
    }

    Card(
        modifier = modifier
            .shadow(
                elevation = if (highlighted) 14.dp else 6.dp,
                shape = RoundedCornerShape(22.dp),
                spotColor = accentColor.copy(alpha = 0.35f)
            )
            .border(
                width = if (highlighted) 1.5.dp else 1.dp,
                brush = borderBrush,
                shape = RoundedCornerShape(22.dp)
            ),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            accentColor.copy(alpha = if (highlighted) 0.09f else 0.03f),
                            Color.Transparent
                        )
                    )
                )
                .padding(16.dp),
            content = content
        )
    }
}

/**
 * Top Hero Header with 3D gym visual background, live Supabase Sync status,
 * QR Code Verifier launcher, Theme toggle, and Lock button.
 */
@Composable
fun CaptainHimaHeroHeader(
    isDarkTheme: Boolean,
    syncStatus: SupabaseSyncStatus,
    onToggleTheme: () -> Unit,
    onOpenVerifier: () -> Unit,
    onSyncClick: () -> Unit,
    onLogoutClick: () -> Unit
) {
    val accent = MaterialTheme.colorScheme.primary

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(26.dp))
            .border(
                width = 1.5.dp,
                brush = Brush.linearGradient(
                    listOf(accent, MetallicGold.copy(alpha = 0.5f), Color.Transparent)
                ),
                shape = RoundedCornerShape(26.dp)
            )
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_gym_hero_banner_1794258965771),
            contentDescription = "Captain Hima Gym Hero Banner",
            modifier = Modifier
                .matchParentSize(),
            contentScale = ContentScale.Crop
        )

        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    Brush.verticalGradient(
                        colors = if (isDarkTheme) {
                            listOf(
                                Color(0xCC050507),
                                Color(0xE6050507),
                                Color(0xF50E1015)
                            )
                        } else {
                            listOf(
                                Color(0xD90D0E12),
                                Color(0xE615171E),
                                Color(0xF21B1E26)
                            )
                        }
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.Black,
                        border = BorderStroke(
                            1.5.dp,
                            Brush.linearGradient(listOf(FieryOrange, MetallicGold))
                        ),
                        modifier = Modifier.size(52.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_captain_hima_logo),
                            contentDescription = "شعار كابتن هيما جيم",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Column {
                        Text(
                            text = "CAPTAIN HIMA FITNESS GYM",
                            style = MaterialTheme.typography.labelMedium,
                            color = MetallicGold,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "لوحة التحكم الإدارية الشاملة",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onToggleTheme,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.12f))
                            .testTag("theme_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "تبديل المظهر الفاتح والداكن",
                            tint = if (isDarkTheme) MetallicGold else FieryOrangeGlow
                        )
                    }

                    IconButton(
                        onClick = onSyncClick,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.12f))
                            .testTag("supabase_sync_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sync,
                            contentDescription = "مزامنة Supabase",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = onLogoutClick,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.12f))
                            .testTag("admin_lock_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "قفل لوحة الإدارة",
                            tint = Color.White.copy(alpha = 0.85f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Supabase & Admin badge
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color.White.copy(alpha = 0.1f),
                    border = BorderStroke(
                        1.dp,
                        if (syncStatus.isConnected) StatusActiveGreen.copy(alpha = 0.6f)
                        else MetallicGold.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = if (syncStatus.isConnected) Icons.Default.CloudDone else Icons.Default.CloudSync,
                            contentDescription = null,
                            tint = if (syncStatus.isConnected) StatusActiveGreen else MetallicGold,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = "hema.gym0@gmail.com",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = onOpenVerifier,
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = accent,
                        contentColor = Color.White
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("open_qr_verifier_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "فاحص الكود #KH",
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

/**
 * Live Top Statistics Strip:
 * - إجمالي المشتركين (Total)
 * - طلبات قيد الانتظار (PENDING)
 * - الاشتراكات النشطة (ACTIVE)
 * - الاشتراكات المجمدة (FROZEN)
 * - الاشتراكات المنتهية (EXPIRED)
 */
@Composable
fun LiveStatisticsRow(
    stats: LiveGymStats,
    selectedStatusFilter: String,
    onStatusCardClick: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatMetricCard(
            title = "إجمالي المشتركين",
            count = stats.totalSubscribers,
            badgeText = "ALL",
            color = MaterialTheme.colorScheme.primary,
            icon = Icons.Default.People,
            isSelected = selectedStatusFilter == "ALL",
            onClick = { onStatusCardClick("ALL") },
            testTag = "stat_card_all"
        )
        StatMetricCard(
            title = "قيد الانتظار",
            count = stats.pendingCount,
            badgeText = "PENDING",
            color = StatusPendingAmber,
            icon = Icons.Default.HourglassTop,
            isSelected = selectedStatusFilter == "PENDING",
            onClick = { onStatusCardClick("PENDING") },
            testTag = "stat_card_pending"
        )
        StatMetricCard(
            title = "الاشتراكات النشطة",
            count = stats.activeCount,
            badgeText = "ACTIVE",
            color = StatusActiveGreen,
            icon = Icons.Default.CheckCircle,
            isSelected = selectedStatusFilter == "ACTIVE",
            onClick = { onStatusCardClick("ACTIVE") },
            testTag = "stat_card_active"
        )
        StatMetricCard(
            title = "الاشتراكات المجمدة",
            count = stats.frozenCount,
            badgeText = "FROZEN",
            color = StatusFrozenCyan,
            icon = Icons.Default.AcUnit,
            isSelected = selectedStatusFilter == "FROZEN",
            onClick = { onStatusCardClick("FROZEN") },
            testTag = "stat_card_frozen"
        )
        StatMetricCard(
            title = "الاشتراكات المنتهية",
            count = stats.expiredCount,
            badgeText = "EXPIRED",
            color = StatusExpiredRed,
            icon = Icons.Default.ErrorOutline,
            isSelected = selectedStatusFilter == "EXPIRED",
            onClick = { onStatusCardClick("EXPIRED") },
            testTag = "stat_card_expired"
        )
    }
}

@Composable
private fun StatMetricCard(
    title: String,
    count: Int,
    badgeText: String,
    color: Color,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val bgAlpha = if (isSelected) 0.18f else 0.07f
    val borderColor by animateColorAsState(
        targetValue = if (isSelected) color else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
        label = "statBorder"
    )

    Surface(
        modifier = Modifier
            .width(142.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(if (isSelected) 1.8.dp else 1.dp, borderColor),
        tonalElevation = if (isSelected) 8.dp else 2.dp
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        listOf(color.copy(alpha = bgAlpha), Color.Transparent)
                    )
                )
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(color.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Text(
                    text = badgeText,
                    style = MaterialTheme.typography.labelMedium,
                    color = color,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun SubscriptionStatusBadge(statusCode: String, statusAr: String) {
    val color = when (statusCode) {
        "ACTIVE" -> StatusActiveGreen
        "PENDING" -> StatusPendingAmber
        "FROZEN" -> StatusFrozenCyan
        "EXPIRED" -> StatusExpiredRed
        "REJECTED", "CANCELLED" -> StatusRejectedRose
        else -> MaterialTheme.colorScheme.primary
    }

    Surface(
        shape = RoundedCornerShape(50),
        color = color.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.65f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Text(
                text = "$statusAr ($statusCode)",
                style = MaterialTheme.typography.labelMedium,
                color = color,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
