package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.GymDatabase
import com.example.data.model.BookingEntity
import com.example.data.model.GymConfigEntity
import com.example.data.model.GymDateUtils
import com.example.data.model.NotificationEntity
import com.example.data.model.PackageCatalogItem
import com.example.data.model.StoryEntity
import com.example.data.model.SubscriptionEntity
import com.example.data.remote.SupabaseService
import com.example.data.remote.SupabaseSyncStatus
import com.example.data.repository.GymAdminRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private val Context.dataStore by preferencesDataStore(name = "captain_hima_admin_prefs")

enum class AdminSection {
    SUBSCRIPTIONS,
    BOOKINGS,
    STORIES,
    NOTIFICATIONS,
    SETTINGS
}

data class LiveGymStats(
    val totalSubscribers: Int = 0,
    val pendingCount: Int = 0,
    val activeCount: Int = 0,
    val frozenCount: Int = 0,
    val expiredCount: Int = 0,
    val pendingBookingsCount: Int = 0
)

class GymAdminViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        const val OFFICIAL_ADMIN_EMAIL = "hema.gym0@gmail.com"
        private val KEY_DARK_THEME = booleanPreferencesKey("is_dark_theme")
        private val KEY_ADMIN_LOGGED_IN = booleanPreferencesKey("is_admin_logged_in")
        private val KEY_SUPABASE_URL = stringPreferencesKey("custom_supabase_url")
        private val KEY_SUPABASE_KEY = stringPreferencesKey("custom_supabase_key")
    }

    private val database = GymDatabase.getInstance(application)
    private val supabaseService = SupabaseService()
    private val repository = GymAdminRepository(database.gymDao(), supabaseService)

    val savedSupabaseUrl: StateFlow<String> = application.dataStore.data
        .map { prefs -> prefs[KEY_SUPABASE_URL] ?: supabaseService.effectiveUrl }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), supabaseService.effectiveUrl)

    val savedSupabaseKey: StateFlow<String> = application.dataStore.data
        .map { prefs -> prefs[KEY_SUPABASE_KEY] ?: supabaseService.effectiveAnonKey }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), supabaseService.effectiveAnonKey)

    val isDarkTheme: StateFlow<Boolean> = application.dataStore.data
        .map { prefs -> prefs[KEY_DARK_THEME] ?: true }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val isAdminAuthenticated: StateFlow<Boolean> = application.dataStore.data
        .map { prefs -> prefs[KEY_ADMIN_LOGGED_IN] ?: true }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    private val _currentSection = MutableStateFlow(AdminSection.SUBSCRIPTIONS)
    val currentSection: StateFlow<AdminSection> = _currentSection.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _statusFilter = MutableStateFlow("ALL")
    val statusFilter: StateFlow<String> = _statusFilter.asStateFlow()

    private val _genderFilter = MutableStateFlow("ALL")
    val genderFilter: StateFlow<String> = _genderFilter.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _verifiedSubscription = MutableStateFlow<SubscriptionEntity?>(null)
    val verifiedSubscription: StateFlow<SubscriptionEntity?> = _verifiedSubscription.asStateFlow()

    private val _verifierCodeInput = MutableStateFlow("")
    val verifierCodeInput: StateFlow<String> = _verifierCodeInput.asStateFlow()

    private val _verifierFeedback = MutableStateFlow<String?>(null)
    val verifierFeedback: StateFlow<String?> = _verifierFeedback.asStateFlow()

    val syncStatus: StateFlow<SupabaseSyncStatus> = repository.syncStatus

    val allSubscriptions: StateFlow<List<SubscriptionEntity>> = repository.subscriptionsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredSubscriptions: StateFlow<List<SubscriptionEntity>> = combine(
        allSubscriptions,
        _searchQuery,
        _statusFilter,
        _genderFilter
    ) { list, query, status, gender ->
        val q = query.trim().removePrefix("#").lowercase()
        list.filter { sub ->
            val matchesQuery = q.isEmpty() ||
                sub.full_name.lowercase().contains(q) ||
                sub.phone.lowercase().contains(q) ||
                sub.code.lowercase().contains(q) ||
                sub.order_number.lowercase().contains(q)

            val matchesStatus = status == "ALL" || sub.status_code == status
            val matchesGender = gender == "ALL" || sub.gender_category == gender
            matchesQuery && matchesStatus && matchesGender
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookings: StateFlow<List<BookingEntity>> = repository.bookingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stories: StateFlow<List<StoryEntity>> = repository.storiesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = repository.notificationsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val gymConfig: StateFlow<GymConfigEntity> = repository.gymConfigFlow
        .map { it ?: GymConfigEntity(id = "main") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), GymConfigEntity(id = "main"))

    val liveStats: StateFlow<LiveGymStats> = combine(allSubscriptions, bookings) { subs, bks ->
        LiveGymStats(
            totalSubscribers = subs.size,
            pendingCount = subs.count { it.status_code == "PENDING" },
            activeCount = subs.count { it.status_code == "ACTIVE" },
            frozenCount = subs.count { it.status_code == "FROZEN" },
            expiredCount = subs.count { it.status_code == "EXPIRED" },
            pendingBookingsCount = bks.count { it.status == "PENDING" }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LiveGymStats())

    init {
        viewModelScope.launch {
            GymDatabase.ensureSeeded(database.gymDao())
            val prefs = getApplication<Application>().dataStore.data.first()
            val storedUrl = prefs[KEY_SUPABASE_URL].orEmpty()
            val storedKey = prefs[KEY_SUPABASE_KEY].orEmpty()
            if (storedUrl.isNotBlank() || storedKey.isNotBlank()) {
                repository.updateRuntimeSupabaseCredentials(storedUrl, storedKey)
            }
            repository.syncWithSupabase()
            // Live auto-sync loop every 12 seconds when Supabase is configured
            while (true) {
                kotlinx.coroutines.delay(12_000L)
                if (supabaseService.isConfigured()) {
                    repository.syncWithSupabase()
                }
            }
        }
    }

    fun saveSupabaseCredentialsAndSync(url: String, anonKey: String) {
        viewModelScope.launch {
            val cleanUrl = url.trim()
            val cleanKey = anonKey.trim()
            getApplication<Application>().dataStore.edit { prefs ->
                prefs[KEY_SUPABASE_URL] = cleanUrl
                prefs[KEY_SUPABASE_KEY] = cleanKey
            }
            repository.updateRuntimeSupabaseCredentials(cleanUrl, cleanKey)
            val ok = repository.syncWithSupabase()
            _toastMessage.value = if (ok) {
                "تم الاتصال والمزامنة بنجاح مع مشروع Supabase!"
            } else {
                repository.syncStatus.value.statusMessageAr
            }
        }
    }

    fun selectSection(section: AdminSection) {
        _currentSection.value = section
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateStatusFilter(status: String) {
        _statusFilter.value = status
    }

    fun updateGenderFilter(gender: String) {
        _genderFilter.value = gender
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun toggleTheme() {
        viewModelScope.launch {
            val current = isDarkTheme.value
            getApplication<Application>().dataStore.edit { prefs ->
                prefs[KEY_DARK_THEME] = !current
            }
        }
    }

    fun setDarkTheme(dark: Boolean) {
        viewModelScope.launch {
            getApplication<Application>().dataStore.edit { prefs ->
                prefs[KEY_DARK_THEME] = dark
            }
        }
    }

    fun loginAdmin(email: String, accessPin: String): Boolean {
        val allowedEmail = gymConfig.value.admin_email.ifBlank { OFFICIAL_ADMIN_EMAIL }.trim().lowercase()
        val entered = email.trim().lowercase()
        return if (entered == allowedEmail || entered == OFFICIAL_ADMIN_EMAIL.lowercase()) {
            if (accessPin.trim().length >= 4) {
                viewModelScope.launch {
                    getApplication<Application>().dataStore.edit { prefs ->
                        prefs[KEY_ADMIN_LOGGED_IN] = true
                    }
                    _toastMessage.value = "مرحباً كابتن هيما! تم تسجيل دخول الإدارة بنجاح"
                }
                true
            } else {
                _toastMessage.value = "يرجى إدخال رمز الحماية الإداري (4 أرقام على الأقل)"
                false
            }
        } else {
            _toastMessage.value = "البريد غير مصرح له! البريد الرسمي: $OFFICIAL_ADMIN_EMAIL"
            false
        }
    }

    fun logoutAdmin() {
        viewModelScope.launch {
            getApplication<Application>().dataStore.edit { prefs ->
                prefs[KEY_ADMIN_LOGGED_IN] = false
            }
            _toastMessage.value = "تم تسجيل الخروج من لوحة التحكم"
        }
    }

    fun triggerSupabaseSync() {
        viewModelScope.launch {
            if (!supabaseService.isConfigured()) {
                _currentSection.value = AdminSection.SETTINGS
                _toastMessage.value = "يرجى إدخال رابط مشروع Supabase (SUPABASE_URL) والمفتاح في بطاقة الربط السحابي بالأسفل"
                return@launch
            }
            val ok = repository.syncWithSupabase()
            _toastMessage.value = if (ok) {
                "تمت المزامنة الفورية مع قاعدة بيانات Supabase بنجاح!"
            } else {
                repository.syncStatus.value.statusMessageAr
            }
        }
    }

    // --- Subscriptions Operations ---
    fun approveSubscription(subscription: SubscriptionEntity) {
        viewModelScope.launch {
            val updated = repository.approveSubscription(subscription)
            if (_verifiedSubscription.value?.code == updated.code) {
                _verifiedSubscription.value = updated
            }
            _toastMessage.value = "تم تفعيل اشتراك ${updated.full_name} (#${updated.code}) وإرسال إشعار ACTIVATED"
        }
    }

    fun rejectSubscription(subscription: SubscriptionEntity) {
        viewModelScope.launch {
            val updated = repository.rejectSubscription(subscription)
            if (_verifiedSubscription.value?.code == updated.code) {
                _verifiedSubscription.value = updated
            }
            _toastMessage.value = "تم رفض الطلب #${updated.code}"
        }
    }

    fun toggleFreezeSubscription(subscription: SubscriptionEntity) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val result = repository.toggleFreezeSubscription(subscription, now)
            result.onSuccess { updated ->
                if (_verifiedSubscription.value?.code == updated.code) {
                    _verifiedSubscription.value = updated
                }
                _toastMessage.value = if (updated.status_code == "FROZEN") {
                    "تم تجميد اشتراك #${updated.code} وإيقاف عداد الأيام عند (${updated.remaining_days} يوم) • رصيد التجميد المتاح: ${updated.freeze_days_available} يوم"
                } else {
                    val freezeMillis = subscription.computeCurrentFreezeDurationMillis(now)
                    val durationText = GymDateUtils.formatDurationAr(freezeMillis)
                    "تم فك تجميد #${updated.code} بعد ($durationText) وتمديد الانتهاء إلى ${updated.end_date} • استئناف العداد (${updated.remaining_days} يوم) • رصيد التجميد المتبقي: ${updated.freeze_days_available} يوم"
                }
            }.onFailure { err ->
                _toastMessage.value = err.message ?: "تعذر تغيير حالة التجميد"
            }
        }
    }

    fun updateFreezeDaysAvailable(subscription: SubscriptionEntity, newFreezeDays: Int) {
        viewModelScope.launch {
            val updated = repository.updateFreezeDaysAvailable(subscription, newFreezeDays)
            if (_verifiedSubscription.value?.code == updated.code) {
                _verifiedSubscription.value = updated
            }
            _toastMessage.value = "تم تحديث رصيد أيام التجميد المتاحة لـ #${updated.code} إلى ${updated.freeze_days_available} يوم"
        }
    }

    fun extendSubscription(subscription: SubscriptionEntity, extraDays: Int) {
        viewModelScope.launch {
            val updated = repository.extendSubscriptionDays(subscription, extraDays)
            if (_verifiedSubscription.value?.code == updated.code) {
                _verifiedSubscription.value = updated
            }
            _toastMessage.value = "تم تمديد اشتراك #${updated.code} بمقدار +$extraDays يوم (ينتهي ${updated.end_date})"
        }
    }

    fun createNewMember(
        code: String,
        fullName: String,
        phone: String,
        genderCategory: String,
        pkg: PackageCatalogItem,
        pricePaidEgp: Int,
        activateImmediately: Boolean
    ) {
        viewModelScope.launch {
            val created = repository.createNewMemberSubscription(
                code = code,
                fullName = fullName,
                phone = phone,
                genderCategory = genderCategory,
                pkg = pkg,
                pricePaidEgp = pricePaidEgp,
                activateImmediately = activateImmediately
            )
            _toastMessage.value = "تم إضافة المشترك ${created.full_name} بكود #${created.code} بنجاح"
        }
    }

    fun useOneFreeInvitation(subscription: SubscriptionEntity) {
        viewModelScope.launch {
            val updated = repository.decrementInvitation(subscription)
            if (_verifiedSubscription.value?.code == updated.code) {
                _verifiedSubscription.value = updated
            }
            _toastMessage.value = "تم خصم دعوة مجانية لـ #${updated.code} (المتبقي: ${updated.free_invitations_left})"
        }
    }

    fun deleteSubscription(code: String) {
        viewModelScope.launch {
            repository.deleteSubscription(code)
            if (_verifiedSubscription.value?.code == code) {
                _verifiedSubscription.value = null
            }
            _toastMessage.value = "تم حذف الاشتراك #$code"
        }
    }

    // --- QR & Code Verifier ---
    fun updateVerifierInput(input: String) {
        _verifierCodeInput.value = input
        _verifierFeedback.value = null
    }

    fun verifyMemberCode(rawCode: String = _verifierCodeInput.value) {
        viewModelScope.launch {
            val clean = rawCode.trim().removePrefix("#").uppercase()
            if (clean.isEmpty()) {
                _verifierFeedback.value = "يرجى إدخال كود العضو (مثال: KH8492A)"
                _verifiedSubscription.value = null
                return@launch
            }
            val found = repository.findSubscriptionByCode(clean)
            if (found != null) {
                _verifiedSubscription.value = found
                _verifierFeedback.value = null
            } else {
                _verifiedSubscription.value = null
                _verifierFeedback.value = "لم يتم العثور على أي اشتراك مسجل بالكود #$clean"
            }
        }
    }

    fun clearVerifiedSubscription() {
        _verifiedSubscription.value = null
        _verifierFeedback.value = null
    }

    // --- Bookings ---
    fun updateBookingStatus(booking: BookingEntity, newStatus: String) {
        viewModelScope.launch {
            repository.updateBookingStatus(booking, newStatus)
            val statusAr = when (newStatus) {
                "ACTIVE" -> "تأكيد وقبول"
                "REJECTED" -> "رفض"
                else -> newStatus
            }
            _toastMessage.value = "تم $statusAr الحجز (${booking.order_number})"
        }
    }

    fun deleteBooking(id: String) {
        viewModelScope.launch {
            repository.deleteBooking(id)
            _toastMessage.value = "تم حذف طلب الحجز"
        }
    }

    private val _isUploadingMedia = MutableStateFlow(false)
    val isUploadingMedia: StateFlow<Boolean> = _isUploadingMedia.asStateFlow()

    fun uploadMediaFromGallery(
        context: Context,
        uri: Uri,
        onResultUrl: (String) -> Unit
    ) {
        viewModelScope.launch {
            _isUploadingMedia.value = true
            val result = repository.uploadGalleryMedia(context, uri)
            _isUploadingMedia.value = false
            result.onSuccess { url ->
                onResultUrl(url)
                _toastMessage.value = if (url.startsWith("https://")) {
                    "تم رفع الوسائط من المعرض إلى سحابة Supabase بنجاح!"
                } else {
                    "تم إرفاق الوسائط من المعرض بنجاح!"
                }
            }.onFailure {
                onResultUrl(uri.toString())
                _toastMessage.value = "تم اختيار الملف من المعرض"
            }
        }
    }

    // --- Stories ---
    fun saveStory(story: StoryEntity) {
        viewModelScope.launch {
            repository.saveStory(story)
            _toastMessage.value = "تم حفظ القصة (${story.title}) وتحديث تطبيق العميل"
        }
    }

    fun toggleStoryActive(story: StoryEntity) {
        viewModelScope.launch {
            repository.toggleStoryActive(story)
            val stateLabel = if (!story.is_active) "إظهار" else "إخفاء"
            _toastMessage.value = "تم $stateLabel القصة (${story.title})"
        }
    }

    fun deleteStory(id: String) {
        viewModelScope.launch {
            repository.deleteStory(id)
            _toastMessage.value = "تم حذف القصة بنجاح"
        }
    }

    // --- Notifications ---
    fun sendOrUpdateNotification(
        id: String?,
        title: String,
        message: String,
        type: String,
        targetCode: String
    ) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val cleanTarget = if (targetCode.isBlank() || targetCode.trim().uppercase() == "ALL") {
                "ALL"
            } else {
                targetCode.trim().removePrefix("#").uppercase()
            }
            val entity = NotificationEntity(
                id = id ?: "notif_${now}",
                title = title.trim(),
                message = message.trim(),
                type = type,
                target_code = cleanTarget,
                is_read = false,
                created_at_utc_millis = now
            )
            repository.saveNotification(entity)
            _toastMessage.value = "تم إرسال الإشعار بنجاح إلى ($cleanTarget)"
        }
    }

    fun deleteNotification(id: String) {
        viewModelScope.launch {
            repository.deleteNotification(id)
            _toastMessage.value = "تم حذف الإشعار من السجل"
        }
    }

    // --- Gym Config ---
    fun saveGymConfig(config: GymConfigEntity) {
        viewModelScope.launch {
            repository.saveGymConfig(config)
            _toastMessage.value = "تم حفظ إعدادات كابتن هيما جيم وتحديث أسعار الباقات والروابط فوراً!"
        }
    }

    fun getPackageCatalog(): List<PackageCatalogItem> {
        return repository.getPackageCatalog(gymConfig.value)
    }

    // --- WhatsApp Confirmation Helper ---
    fun openWhatsAppForMember(context: Context, subscription: SubscriptionEntity) {
        val rawPhone = subscription.phone.replace(Regex("[^0-9]"), "")
        val intlPhone = when {
            rawPhone.startsWith("20") -> rawPhone
            rawPhone.startsWith("0") -> "2$rawPhone"
            else -> "20$rawPhone"
        }
        val liveRemaining = subscription.computeLiveRemainingDays()
        val message = buildString {
            appendLine("🔥 *CAPTAIN HIMA FITNESS GYM* 🔥")
            appendLine("مرحباً بطلنا *${subscription.full_name}* 💪")
            appendLine("تم تحديث حالة اشتراكك في كابتن هيما جيم:")
            appendLine("• كود العضوية: *#${subscription.code}*")
            appendLine("• رقم الطلب: ${subscription.order_number}")
            appendLine("• الباقة: *${subscription.package_title}*")
            appendLine("• الحالة: *${subscription.status_ar}* (${subscription.status_code})")
            appendLine("• الأيام المتبقية: *$liveRemaining يوم*")
            appendLine("• تاريخ الانتهاء: ${subscription.end_date}")
            appendLine("• الدعوات المجانية المتبقية: ${subscription.free_invitations_left}")
            appendLine("ننتظرك في التمرين! 🏆")
        }
        val url = "https://wa.me/$intlPhone?text=${Uri.encode(message)}"
        runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }.onFailure {
            _toastMessage.value = "تعذر فتح تطبيق واتساب على هذا الجهاز"
        }
    }

    fun openExternalUrl(context: Context, url: String) {
        if (url.isBlank()) return
        runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}
