package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Mode (3D Glass Luxury Dark)
val LuxuryDarkBackground = Color(0xFF050507)
val LuxuryDarkGlassCard = Color(0xFF0E1015)
val LuxuryDarkGlassElevated = Color(0xFF161922)
val LuxuryDarkGlassBorder = Color(0xFF262936)
val FieryOrange = Color(0xFFFF5E00)
val FieryOrangeGlow = Color(0xFFFF8533)
val DarkModeTextPrimary = Color(0xFFFFFFFF)
val DarkModeTextSecondary = Color(0xFFA0A6B5)

// Light Mode (Royal White & Royal Gold)
val RoyalLightBackground = Color(0xFFFAF8F3)
val RoyalLightCard = Color(0xFFFFFFFF)
val RoyalLightElevated = Color(0xFFF3EFE6)
val RoyalLightBorder = Color(0xFFE4DCCB)
val RoyalGold = Color(0xFFB8860B)
val MetallicGold = Color(0xFFD4AF37)
val LightModeTextPrimary = Color(0xFF0D0E12)
val LightModeTextSecondary = Color(0xFF525663)

// Semantic Status Colors
val StatusActiveGreen = Color(0xFF10B981)
val StatusPendingAmber = Color(0xFFF59E0B)
val StatusFrozenCyan = Color(0xFF06B6D4)
val StatusExpiredRed = Color(0xFFEF4444)
val StatusRejectedRose = Color(0xFFE11D48)
val WhatsAppGreen = Color(0xFF25D366)
