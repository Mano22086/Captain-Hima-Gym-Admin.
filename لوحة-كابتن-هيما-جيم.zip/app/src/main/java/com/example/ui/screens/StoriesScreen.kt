package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.StoryEntity
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusExpiredRed

private fun isImageUrl(url: String): Boolean {
    val lower = url.lowercase()
    return lower.endsWith(".jpg") ||
        lower.endsWith(".jpeg") ||
        lower.endsWith(".png") ||
        lower.endsWith(".webp") ||
        lower.contains("image")
}

@Composable
fun StoriesScreen(
    stories: List<StoryEntity>,
    isUploadingMedia: Boolean,
    onUploadGalleryMedia: (Uri, (String) -> Unit) -> Unit,
    onSaveStory: (StoryEntity) -> Unit,
    onToggleStoryActive: (StoryEntity) -> Unit,
    onDeleteStory: (String) -> Unit,
    onOpenVideoUrl: (String) -> Unit
) {
    var editingStory by remember { mutableStateOf<StoryEntity?>(null) }
    var preselectedGalleryUrl by remember { mutableStateOf<String?>(null) }
    var isEditorOpen by remember { mutableStateOf(false) }

    // Top-level quick gallery picker for adding a story directly from gallery
    val quickStoryGalleryPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onUploadGalleryMedia(uri) { uploadedUrl ->
                editingStory = null
                preselectedGalleryUrl = uploadedUrl
                isEditorOpen = true
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "إدارة القصص والريلز (stories)",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "إضافة فيديو أو صورة من المعرض أو تعديل وإخفاء/إظهار القصص المعروضة في تطبيق العميل",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = {
                        quickStoryGalleryPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                        )
                    },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .weight(1.3f)
                        .height(48.dp)
                        .testTag("add_story_from_gallery_button")
                ) {
                    if (isUploadingMedia) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(18.dp)
                        )
                    } else {
                        Icon(Icons.Default.Collections, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("إضافة فيديو/صورة من المعرض", style = MaterialTheme.typography.labelLarge)
                }

                OutlinedButton(
                    onClick = {
                        editingStory = null
                        preselectedGalleryUrl = null
                        isEditorOpen = true
                    },
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .weight(0.9f)
                        .height(48.dp)
                        .testTag("add_new_story_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("قصة جديدة", style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(stories, key = { it.id }) { story ->
                LuxuryGlassCard(
                    accentColor = if (story.is_active) MaterialTheme.colorScheme.primary else StatusExpiredRed,
                    highlighted = story.is_active,
                    modifier = Modifier.testTag("story_card_${story.id}")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                            ) {
                                Text(
                                    text = "#${story.sort_order} • ${story.category_tag}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MetallicGold.copy(alpha = 0.14f)
                            ) {
                                Text(
                                    text = story.badge_text,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MetallicGold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (story.is_active) "ظاهر" else "مخفي",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (story.is_active) StatusActiveGreen else StatusExpiredRed
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Switch(
                                checked = story.is_active,
                                onCheckedChange = { onToggleStoryActive(story) },
                                modifier = Modifier.testTag("toggle_story_active_${story.id}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Media preview if story URL is an image
                    if (isImageUrl(story.video_url)) {
                        AsyncImage(
                            model = story.video_url,
                            contentDescription = story.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(14.dp))
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    Text(
                        text = story.title,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = story.subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "زر الحجز المرتبط: ${story.program_to_book} (${story.booking_type_preset} • ${story.gender_preset})",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    Icons.Default.MusicNote,
                                    contentDescription = null,
                                    tint = MetallicGold,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = story.audio_track_title,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = story.video_url,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.clickable { onOpenVideoUrl(story.video_url) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Favorite,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${story.likes_count}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Share,
                                    contentDescription = null,
                                    tint = MetallicGold,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${story.shares_count}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { onOpenVideoUrl(story.video_url) },
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.PlayCircleFilled, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("معاينة")
                            }

                            OutlinedButton(
                                onClick = {
                                    editingStory = story
                                    preselectedGalleryUrl = null
                                    isEditorOpen = true
                                },
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("edit_story_${story.id}")
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تعديل")
                            }

                            IconButton(
                                onClick = { onDeleteStory(story.id) },
                                modifier = Modifier.testTag("delete_story_${story.id}")
                            ) {
                                Icon(
                                    Icons.Default.DeleteOutline,
                                    contentDescription = "حذف القصة",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(88.dp)) }
        }
    }

    if (isEditorOpen) {
        StoryEditorDialog(
            initialStory = editingStory,
            preselectedMediaUrl = preselectedGalleryUrl,
            isUploadingMedia = isUploadingMedia,
            onUploadGalleryMedia = onUploadGalleryMedia,
            nextSortOrder = (stories.maxOfOrNull { it.sort_order } ?: 0) + 1,
            onDismiss = {
                isEditorOpen = false
                preselectedGalleryUrl = null
            },
            onSave = { saved ->
                onSaveStory(saved)
                isEditorOpen = false
                preselectedGalleryUrl = null
            }
        )
    }
}

@Composable
private fun StoryEditorDialog(
    initialStory: StoryEntity?,
    preselectedMediaUrl: String?,
    isUploadingMedia: Boolean,
    onUploadGalleryMedia: (Uri, (String) -> Unit) -> Unit,
    nextSortOrder: Int,
    onDismiss: () -> Unit,
    onSave: (StoryEntity) -> Unit
) {
    var title by remember { mutableStateOf(initialStory?.title ?: "") }
    var subtitle by remember { mutableStateOf(initialStory?.subtitle ?: "") }
    var badgeText by remember { mutableStateOf(initialStory?.badge_text ?: "حصرياً في كابتن هيما جيم") }
    var categoryTag by remember { mutableStateOf(initialStory?.category_tag ?: "صالة الحديد") }
    var programToBook by remember { mutableStateOf(initialStory?.program_to_book ?: "باقة 3 شهور - وحوش الحديد") }
    var bookingTypePreset by remember { mutableStateOf(initialStory?.booking_type_preset ?: "اشتراك باقة") }
    var genderPreset by remember { mutableStateOf(initialStory?.gender_preset ?: "قسم الرجال") }
    var videoUrl by remember {
        mutableStateOf(
            preselectedMediaUrl
                ?: initialStory?.video_url
                ?: "https://assets.mixkit.co/videos/preview/mixkit-man-training-in-the-gym-22854-large.mp4"
        )
    }
    var audioTrackTitle by remember { mutableStateOf(initialStory?.audio_track_title ?: "Captain Hima Official Workout Mix") }
    var sortOrder by remember { mutableStateOf((initialStory?.sort_order ?: nextSortOrder).toString()) }
    var isActive by remember { mutableStateOf(initialStory?.is_active ?: true) }

    val galleryMediaPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onUploadGalleryMedia(uri) { uploadedUrl ->
                videoUrl = uploadedUrl
            }
        }
    }

    val categories = listOf("صالة الحديد", "الحصص الجماعية", "السبا والجاكوزي", "قسم السيدات")
    val bookingTypes = listOf("اشتراك باقة", "حجز حصة جماعية")
    val genders = listOf("قسم الرجال", "قسم السيدات")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        LuxuryGlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            highlighted = true
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (initialStory == null) "إضافة قصة / ريلز جديد" else "تعديل القصة (${initialStory.id})",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                // Gallery Picker Section inside Story Editor
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "اختيار فيديو أو صورة من معرض الهاتف:",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    galleryMediaPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                    )
                                },
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("pick_story_video_button")
                            ) {
                                Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("اختيار فيديو", style = MaterialTheme.typography.labelLarge)
                            }

                            Button(
                                onClick = {
                                    galleryMediaPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MetallicGold,
                                    contentColor = Color.Black
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("pick_story_image_button")
                            ) {
                                Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("اختيار صورة", style = MaterialTheme.typography.labelLarge)
                            }
                        }

                        if (isUploadingMedia) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Text(
                                    text = "جاري تجهيز ورفع الملف المختار من المعرض...",
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        } else if (isImageUrl(videoUrl)) {
                            AsyncImage(
                                model = videoUrl,
                                contentDescription = "معاينة صورة القصة",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(140.dp)
                                    .clip(RoundedCornerShape(12.dp))
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان القصة (title)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("story_title_input")
                )

                OutlinedTextField(
                    value = subtitle,
                    onValueChange = { subtitle = it },
                    label = { Text("الوصف الفرعي (subtitle)") },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("story_subtitle_input")
                )

                OutlinedTextField(
                    value = badgeText,
                    onValueChange = { badgeText = it },
                    label = { Text("الشارة العلوية (badge_text)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Text("التصنيف (category_tag):", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = categoryTag == cat,
                            onClick = { categoryTag = cat },
                            label = { Text(cat) }
                        )
                    }
                }

                OutlinedTextField(
                    value = programToBook,
                    onValueChange = { programToBook = it },
                    label = { Text("الباقة أو الحصة المرتبطة بالحجز (program_to_book)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Text("نوع الحجز المسبق (booking_type_preset):", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    bookingTypes.forEach { bt ->
                        FilterChip(
                            selected = bookingTypePreset == bt,
                            onClick = { bookingTypePreset = bt },
                            label = { Text(bt) }
                        )
                    }
                }

                Text("القسم المستهدف (gender_preset):", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    genders.forEach { g ->
                        FilterChip(
                            selected = genderPreset == g,
                            onClick = { genderPreset = g },
                            label = { Text(g) }
                        )
                    }
                }

                OutlinedTextField(
                    value = videoUrl,
                    onValueChange = { videoUrl = it },
                    label = { Text("رابط الفيديو أو الصورة (يتم تعبئته تلقائياً من المعرض)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("story_video_url_input")
                )

                OutlinedTextField(
                    value = audioTrackTitle,
                    onValueChange = { audioTrackTitle = it },
                    label = { Text("اسم المقطع الصوتي (audio_track_title)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = sortOrder,
                    onValueChange = { sortOrder = it },
                    label = { Text("ترتيب الظهور (sort_order)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء")
                    }
                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                val entity = StoryEntity(
                                    id = initialStory?.id ?: "story_${System.currentTimeMillis()}",
                                    title = title.trim(),
                                    subtitle = subtitle.trim(),
                                    badge_text = badgeText.trim(),
                                    category_tag = categoryTag,
                                    program_to_book = programToBook.trim(),
                                    booking_type_preset = bookingTypePreset,
                                    gender_preset = genderPreset,
                                    video_url = videoUrl.trim(),
                                    audio_track_title = audioTrackTitle.trim(),
                                    likes_count = initialStory?.likes_count ?: 100,
                                    shares_count = initialStory?.shares_count ?: 25,
                                    sort_order = sortOrder.toIntOrNull() ?: nextSortOrder,
                                    is_active = isActive
                                )
                                onSave(entity)
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1.4f)
                            .testTag("save_story_button")
                    ) {
                        Text("حفظ ونشر القصة")
                    }
                }
            }
        }
    }
}
