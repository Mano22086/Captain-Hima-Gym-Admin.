package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.PauseCircleFilled
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.GymDateUtils
import com.example.data.model.PackageCatalogItem
import com.example.data.model.SubscriptionEntity
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.components.SubscriptionStatusBadge
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusExpiredRed
import com.example.ui.theme.StatusFrozenCyan
import com.example.ui.theme.StatusPendingAmber
import com.example.ui.theme.StatusRejectedRose
import com.example.ui.theme.WhatsAppGreen
import kotlin.math.max

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SubscriptionsScreen(
    subscriptions: List<SubscriptionEntity>,
    allSubscriptions: List<SubscriptionEntity>,
    searchQuery: String,
    statusFilter: String,
    genderFilter: String,
    packageCatalog: List<PackageCatalogItem>,
    showVerifierModal: Boolean,
    verifierCodeInput: String,
    verifiedSubscription: SubscriptionEntity?,
    verifierFeedback: String?,
    onSearchQueryChange: (String) -> Unit,
    onStatusFilterChange: (String) -> Unit,
    onGenderFilterChange: (String) -> Unit,
    onApprove: (SubscriptionEntity) -> Unit,
    onReject: (SubscriptionEntity) -> Unit,
    onToggleFreeze: (SubscriptionEntity) -> Unit,
    onUpdateFreezeDaysAvailable: (SubscriptionEntity, Int) -> Unit,
    onExtendDays: (SubscriptionEntity, Int) -> Unit,
    onUseInvitation: (SubscriptionEntity) -> Unit,
    onDeleteSubscription: (String) -> Unit,
    onWhatsAppMember: (SubscriptionEntity) -> Unit,
    onCreateMember: (String, String, String, String, PackageCatalogItem, Int, Boolean) -> Unit,
    onOpenVerifierModal: () -> Unit,
    onCloseVerifierModal: () -> Unit,
    onVerifierInputChange: (String) -> Unit,
    onVerifyCode: (String) -> Unit
) {
    var showAddMemberModal by remember { mutableStateOf(false) }
    var freezeDialogTargetCode by remember { mutableStateOf<String?>(null) }

    val freezeDialogSubscription = remember(allSubscriptions, freezeDialogTargetCode) {
        freezeDialogTargetCode?.let { code -> allSubscriptions.find { it.code == code } }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Top Action Bar: Search + Quick Buttons (Add Member #KH + Code Verifier)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { showAddMemberModal = true },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("add_new_member_button")
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("إضافة مشترك + كود #KH", style = MaterialTheme.typography.labelLarge)
                }

                OutlinedButton(
                    onClick = onOpenVerifierModal,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("verifier_secondary_button")
                ) {
                    Icon(
                        Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("فحص كود", style = MaterialTheme.typography.labelLarge)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("ابحث بالاسم أو رقم الهاتف أو كود الاشتراك (#KH...)") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "مسح البحث")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("subscription_search_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Status Filter Chips
            val statusOptions = listOf(
                "ALL" to "الكل (${allSubscriptions.size})",
                "PENDING" to "قيد الانتظار PENDING",
                "ACTIVE" to "نشط ACTIVE",
                "FROZEN" to "مجمد FROZEN",
                "EXPIRED" to "منتهي EXPIRED",
                "REJECTED" to "مرفوض REJECTED"
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                statusOptions.forEach { (code, label) ->
                    FilterChip(
                        selected = statusFilter == code,
                        onClick = { onStatusFilterChange(code) },
                        label = { Text(label, style = MaterialTheme.typography.labelMedium) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                            selectedLabelColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.testTag("filter_status_$code")
                    )
                }
            }

            // Gender Filter Chips
            val genderOptions = listOf(
                "ALL" to "جميع الأقسام",
                "قسم الرجال" to "💪 قسم الرجال",
                "قسم السيدات" to "👑 قسم السيدات"
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                genderOptions.forEach { (genderKey, label) ->
                    FilterChip(
                        selected = genderFilter == genderKey,
                        onClick = { onGenderFilterChange(genderKey) },
                        label = { Text(label, style = MaterialTheme.typography.labelMedium) },
                        modifier = Modifier.testTag("filter_gender_$genderKey")
                    )
                }
            }
        }

        // Subscriptions List
        if (subscriptions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.QrCode2,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "لا توجد اشتراكات مطابقة للبحث أو الفلتر المحدد",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(subscriptions, key = { it.code }) { sub ->
                    SubscriptionAdminCard(
                        subscription = sub,
                        onApprove = { onApprove(sub) },
                        onReject = { onReject(sub) },
                        onToggleFreeze = { onToggleFreeze(sub) },
                        onOpenFreezeDetails = { freezeDialogTargetCode = sub.code },
                        onUpdateFreezeDaysAvailable = { newDays ->
                            onUpdateFreezeDaysAvailable(sub, newDays)
                        },
                        onExtendDays = { days -> onExtendDays(sub, days) },
                        onUseInvitation = { onUseInvitation(sub) },
                        onDelete = { onDeleteSubscription(sub.code) },
                        onWhatsApp = { onWhatsAppMember(sub) },
                        onInspectQr = {
                            onVerifierInputChange(sub.code)
                            onVerifyCode(sub.code)
                            onOpenVerifierModal()
                        }
                    )
                }
                item { Spacer(modifier = Modifier.height(88.dp)) }
            }
        }
    }

    if (showAddMemberModal) {
        AddNewMemberDialog(
            packageCatalog = packageCatalog,
            onDismiss = { showAddMemberModal = false },
            onConfirm = { code, fullName, phone, gender, pkg, price, activateNow ->
                onCreateMember(code, fullName, phone, gender, pkg, price, activateNow)
                showAddMemberModal = false
            }
        )
    }

    if (freezeDialogSubscription != null) {
        FreezeManagementDialog(
            subscription = freezeDialogSubscription,
            onToggleFreeze = { onToggleFreeze(freezeDialogSubscription) },
            onUpdateFreezeDaysAvailable = { newDays ->
                onUpdateFreezeDaysAvailable(freezeDialogSubscription, newDays)
            },
            onDismiss = { freezeDialogTargetCode = null }
        )
    }

    if (showVerifierModal) {
        QrAndCodeVerifierDialog(
            codeInput = verifierCodeInput,
            verifiedSubscription = verifiedSubscription,
            feedbackMessage = verifierFeedback,
            recentSubscriptions = allSubscriptions.take(6),
            onInputChange = onVerifierInputChange,
            onVerifyClick = { onVerifyCode(verifierCodeInput) },
            onSelectQuickCode = { code ->
                onVerifierInputChange(code)
                onVerifyCode(code)
            },
            onApprove = { sub -> onApprove(sub) },
            onToggleFreeze = { sub -> onToggleFreeze(sub) },
            onExtendDays = { sub, days -> onExtendDays(sub, days) },
            onUseInvitation = { sub -> onUseInvitation(sub) },
            onWhatsApp = { sub -> onWhatsAppMember(sub) },
            onDismiss = onCloseVerifierModal
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SubscriptionAdminCard(
    subscription: SubscriptionEntity,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onToggleFreeze: () -> Unit,
    onOpenFreezeDetails: () -> Unit,
    onUpdateFreezeDaysAvailable: (Int) -> Unit,
    onExtendDays: (Int) -> Unit,
    onUseInvitation: () -> Unit,
    onDelete: () -> Unit,
    onWhatsApp: () -> Unit,
    onInspectQr: () -> Unit
) {
    val nowMillis = System.currentTimeMillis()
    val liveRemaining = subscription.computeLiveRemainingDays(nowMillis)
    val isFrozen = subscription.status_code == "FROZEN"
    val accentColor = when (subscription.status_code) {
        "PENDING" -> StatusPendingAmber
        "ACTIVE" -> StatusActiveGreen
        "FROZEN" -> StatusFrozenCyan
        "EXPIRED" -> StatusExpiredRed
        else -> StatusRejectedRose
    }

    LuxuryGlassCard(
        accentColor = accentColor,
        highlighted = subscription.status_code == "PENDING" || isFrozen,
        modifier = Modifier.testTag("subscription_card_${subscription.code}")
    ) {
        // Header row: Code badge + Order Number + Status badge
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                    modifier = Modifier.clickable(onClick = onInspectQr)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode2,
                            contentDescription = "عرض بطاقة الكود",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "#${subscription.code}",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Text(
                    text = subscription.order_number,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            SubscriptionStatusBadge(
                statusCode = subscription.status_code,
                statusAr = subscription.status_ar
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Subscriber Name, Gender, and Phone
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = subscription.full_name,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = subscription.phone,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text("•", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = subscription.gender_category,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (subscription.gender_category.contains("السيدات")) MetallicGold else MaterialTheme.colorScheme.primary
                    )
                }
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.testTag("delete_sub_${subscription.code}")
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "حذف الاشتراك",
                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.75f)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Package & Days Grid
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${subscription.package_title} (${subscription.package_id})",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${subscription.price_paid_egp} ج.م",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        if (isFrozen) {
                            Icon(
                                imageVector = Icons.Default.PauseCircleFilled,
                                contentDescription = "العداد متوقف",
                                tint = StatusFrozenCyan,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Text(
                            text = if (isFrozen) {
                                "الأيام المتبقية: $liveRemaining من ${subscription.total_days} يوم (متوقف مؤقتاً ❄️)"
                            } else {
                                "الأيام المتبقية: $liveRemaining من ${subscription.total_days} يوم"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = when {
                                isFrozen -> StatusFrozenCyan
                                liveRemaining <= 5 -> StatusExpiredRed
                                else -> StatusActiveGreen
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "الدعوات: ${subscription.free_invitations_left}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "البداية: ${subscription.start_date}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "الانتهاء: ${subscription.end_date}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Freeze Status & Quota Management Section (for ACTIVE and FROZEN subscriptions)
        if (subscription.status_code == "ACTIVE" || isFrozen) {
            Spacer(modifier = Modifier.height(10.dp))
            FreezeStatusAndQuotaBanner(
                subscription = subscription,
                nowMillis = nowMillis,
                onOpenFreezeDetails = onOpenFreezeDetails,
                onUpdateFreezeDaysAvailable = onUpdateFreezeDaysAvailable
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Primary Admin Actions: Approve / Reject / Freeze-Unfreeze / WhatsApp
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (subscription.status_code == "PENDING" || subscription.status_code == "REJECTED") {
                Button(
                    onClick = onApprove,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StatusActiveGreen,
                        contentColor = Color.White
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("approve_button_${subscription.code}")
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("قبول وتفعيل (Approve)", style = MaterialTheme.typography.labelLarge)
                }
            }

            if (subscription.status_code == "PENDING") {
                OutlinedButton(
                    onClick = onReject,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StatusRejectedRose),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRejectedRose),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("reject_button_${subscription.code}")
                ) {
                    Icon(Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("رفض الطلب (Reject)", style = MaterialTheme.typography.labelLarge)
                }
            }

            if (subscription.status_code == "ACTIVE" || isFrozen) {
                val canFreeze = isFrozen || subscription.freeze_days_available > 0
                Button(
                    onClick = onToggleFreeze,
                    enabled = canFreeze,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isFrozen) StatusActiveGreen else StatusFrozenCyan,
                        contentColor = Color.White,
                        disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("freeze_toggle_button_${subscription.code}")
                ) {
                    Icon(
                        imageVector = if (isFrozen) Icons.Default.PlayArrow else Icons.Default.AcUnit,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = when {
                            isFrozen -> "فك التجميد وتمديد المدة (Unfreeze)"
                            canFreeze -> "تجميد الاشتراك (Freeze)"
                            else -> "رصيد التجميد 0 يوم"
                        },
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }

            // WhatsApp Confirmation Button
            OutlinedButton(
                onClick = onWhatsApp,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, WhatsAppGreen),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = WhatsAppGreen),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier.testTag("whatsapp_button_${subscription.code}")
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(5.dp))
                Text("تأكيد عبر واتساب", style = MaterialTheme.typography.labelLarge)
            }

            if (subscription.free_invitations_left > 0 && subscription.status_code == "ACTIVE") {
                OutlinedButton(
                    onClick = onUseInvitation,
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Default.CardGiftcard, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(5.dp))
                    Text("خصم دعوة (${subscription.free_invitations_left})", style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
        Spacer(modifier = Modifier.height(8.dp))

        // Extension Row: +7 / +15 / +30 / +90 Days
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AddCircleOutline,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "تمديد الاشتراك:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(7, 15, 30, 90).forEach { extraDays ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onExtendDays(extraDays) }
                            .testTag("extend_${extraDays}_days_${subscription.code}")
                    ) {
                        Text(
                            text = "+$extraDays ي",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Dedicated banner inside subscription card displaying:
 * - Available freeze days (`freeze_days_available`) with +/- quick adjustments
 * - Current freeze timestamp (`frozen_at_utc_millis`), elapsed freeze time, and projected new expiry date when FROZEN
 * - Accumulated freeze duration (`accumulated_freeze_millis`)
 */
@Composable
private fun FreezeStatusAndQuotaBanner(
    subscription: SubscriptionEntity,
    nowMillis: Long,
    onOpenFreezeDetails: () -> Unit,
    onUpdateFreezeDaysAvailable: (Int) -> Unit
) {
    val isFrozen = subscription.status_code == "FROZEN"
    val currentFreezeMillis = subscription.computeCurrentFreezeDurationMillis(nowMillis)
    val projectedUnfrozen = if (isFrozen) subscription.unfreezeAt(nowMillis) else null

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (isFrozen) StatusFrozenCyan.copy(alpha = 0.12f)
        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        border = BorderStroke(
            width = if (isFrozen) 1.5.dp else 1.dp,
            color = if (isFrozen) StatusFrozenCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenFreezeDetails)
            .testTag("freeze_status_banner_${subscription.code}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AcUnit,
                        contentDescription = null,
                        tint = StatusFrozenCyan,
                        modifier = Modifier.size(17.dp)
                    )
                    Text(
                        text = "رصيد التجميد المتاح: ${subscription.freeze_days_available} يوم",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (subscription.freeze_days_available > 0) StatusFrozenCyan else StatusExpiredRed,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Quick +/- controls for freeze_days_available
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable {
                                onUpdateFreezeDaysAvailable(max(0, subscription.freeze_days_available - 1))
                            }
                            .testTag("decrease_freeze_days_${subscription.code}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Remove,
                            contentDescription = "إنقاص أيام التجميد",
                            modifier = Modifier
                                .padding(4.dp)
                                .size(14.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = StatusFrozenCyan.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, StatusFrozenCyan),
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable {
                                onUpdateFreezeDaysAvailable(subscription.freeze_days_available + 7)
                            }
                            .testTag("increase_freeze_days_${subscription.code}")
                    ) {
                        Text(
                            text = "+7 رصيد",
                            style = MaterialTheme.typography.labelMedium,
                            color = StatusFrozenCyan,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            if (isFrozen && subscription.frozen_at_utc_millis != null && projectedUnfrozen != null) {
                HorizontalDivider(color = StatusFrozenCyan.copy(alpha = 0.3f))
                Text(
                    text = "❄️ مجمد منذ: ${GymDateUtils.formatReadableAr(subscription.frozen_at_utc_millis)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "⏱️ مدة التجميد الحالية: ${GymDateUtils.formatDurationAr(currentFreezeMillis)} (يُستهلك ${subscription.computeFrozenDaysUsed(currentFreezeMillis)} يوم من الرصيد)",
                    style = MaterialTheme.typography.labelMedium,
                    color = StatusFrozenCyan,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "📅 الانتهاء الجديد عند فك التجميد الآن: ${projectedUnfrozen.end_date} (الرصيد المتبقي: ${projectedUnfrozen.freeze_days_available} يوم)",
                    style = MaterialTheme.typography.labelMedium,
                    color = StatusActiveGreen,
                    fontWeight = FontWeight.Bold
                )
            } else if (subscription.accumulated_freeze_millis > 0L) {
                Text(
                    text = "إجمالي فترات التجميد السابقة: ${GymDateUtils.formatDurationAr(subscription.accumulated_freeze_millis)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/**
 * Detailed Modal Dialog for inspecting and managing Freeze / Unfreeze calculations.
 */
@Composable
private fun FreezeManagementDialog(
    subscription: SubscriptionEntity,
    onToggleFreeze: () -> Unit,
    onUpdateFreezeDaysAvailable: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val nowMillis = System.currentTimeMillis()
    val isFrozen = subscription.status_code == "FROZEN"
    val liveRemaining = subscription.computeLiveRemainingDays(nowMillis)
    val currentFreezeMillis = subscription.computeCurrentFreezeDurationMillis(nowMillis)
    val previewUnfrozen = if (isFrozen) subscription.unfreezeAt(nowMillis) else null

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        LuxuryGlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            accentColor = StatusFrozenCyan,
            highlighted = true
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AcUnit,
                            contentDescription = null,
                            tint = StatusFrozenCyan
                        )
                        Text(
                            text = "إدارة تجميد الاشتراك #${subscription.code}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                Text(
                    text = "${subscription.full_name} • ${subscription.package_title}",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    border = BorderStroke(1.dp, StatusFrozenCyan.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "حالة الاشتراك الحالية: ${subscription.status_ar} (${subscription.status_code})",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (isFrozen) StatusFrozenCyan else StatusActiveGreen,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "عداد الأيام المتبقية (remaining_days): $liveRemaining يوم ${if (isFrozen) "(متوقف مؤقتاً ❄️)" else "(يعمل بنشاط)"}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "أيام التجميد المتاحة (freeze_days_available): ${subscription.freeze_days_available} يوم",
                            style = MaterialTheme.typography.bodyMedium,
                            color = StatusFrozenCyan,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "إجمالي التجميد المتراكم السابق: ${GymDateUtils.formatDurationAr(subscription.accumulated_freeze_millis)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (isFrozen && subscription.frozen_at_utc_millis != null && previewUnfrozen != null) {
                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 4.dp),
                                color = StatusFrozenCyan.copy(alpha = 0.3f)
                            )
                            Text(
                                text = "تفاصيل حساب فك التجميد التلقائي:",
                                style = MaterialTheme.typography.labelLarge,
                                color = MetallicGold
                            )
                            Text(
                                text = "• وقت بدء التجميد: ${GymDateUtils.formatReadableAr(subscription.frozen_at_utc_millis)}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "• مدة التجميد المحسوبة: ${GymDateUtils.formatDurationAr(currentFreezeMillis)}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "• تاريخ الانتهاء قبل فك التجميد: ${subscription.end_date}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "• تاريخ الانتهاء الجديد بعد الإضافة: ${previewUnfrozen.end_date}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = StatusActiveGreen,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "• رصيد التجميد المتبقي بعد الخصم: ${previewUnfrozen.freeze_days_available} يوم",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }

                // Manage freeze_days_available quota
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "تعديل رصيد أيام التجميد المتاحة:",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = { onUpdateFreezeDaysAvailable(max(0, subscription.freeze_days_available - 1)) },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("-1 يوم")
                        }
                        OutlinedButton(
                            onClick = { onUpdateFreezeDaysAvailable(subscription.freeze_days_available + 7) },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("+7 أيام")
                        }
                        OutlinedButton(
                            onClick = { onUpdateFreezeDaysAvailable(subscription.freeze_days_available + 15) },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("+15 يوم")
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إغلاق")
                    }

                    Button(
                        onClick = {
                            onToggleFreeze()
                            onDismiss()
                        },
                        enabled = isFrozen || subscription.freeze_days_available > 0,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isFrozen) StatusActiveGreen else StatusFrozenCyan,
                            contentColor = Color.White
                        ),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Icon(
                            imageVector = if (isFrozen) Icons.Default.PlayArrow else Icons.Default.AcUnit,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isFrozen) "تأكيد فك التجميد وتمديد الاشتراك" else "تأكيد تجميد الاشتراك الآن",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

/**
 * Modal Dialog: إضافة مشترك جديد وتوليد كود عشوائي فوري (#KH...)
 */
@Composable
private fun AddNewMemberDialog(
    packageCatalog: List<PackageCatalogItem>,
    onDismiss: () -> Unit,
    onConfirm: (
        code: String,
        fullName: String,
        phone: String,
        gender: String,
        pkg: PackageCatalogItem,
        pricePaid: Int,
        activateImmediately: Boolean
    ) -> Unit
) {
    var generatedCode by remember { mutableStateOf(GymDateUtils.generateRandomMemberCode()) }
    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var selectedGender by remember { mutableStateOf("قسم الرجال") }
    var selectedPkg by remember { mutableStateOf(packageCatalog.first()) }
    var priceInput by remember { mutableStateOf(selectedPkg.defaultPriceEgp.toString()) }
    var activateImmediately by remember { mutableStateOf(true) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        LuxuryGlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            highlighted = true
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "إضافة مشترك جديد وتوليد كود فوري",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Instant #KH... Code Generator Banner
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "كود العضوية الفوري (Primary Key)",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "#$generatedCode",
                                style = MaterialTheme.typography.headlineLarge,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        OutlinedButton(
                            onClick = { generatedCode = GymDateUtils.generateRandomMemberCode() },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("regenerate_kh_code_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("توليد كود جديد")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = fullName,
                    onValueChange = {
                        fullName = it
                        errorMsg = null
                    },
                    label = { Text("اسم المشترك الثلاثي (full_name)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_member_name_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = {
                        phone = it
                        errorMsg = null
                    },
                    label = { Text("رقم الهاتف / واتساب (phone)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_member_phone_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "القسم (gender_category):",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    listOf("قسم الرجال", "قسم السيدات").forEach { gender ->
                        FilterChip(
                            selected = selectedGender == gender,
                            onClick = { selectedGender = gender },
                            label = { Text(gender) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "اختر الباقة (package_id):",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))

                packageCatalog.forEach { pkg ->
                    val isSelected = selectedPkg.packageId == pkg.packageId
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = BorderStroke(
                            if (isSelected) 1.5.dp else 1.dp,
                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                selectedPkg = pkg
                                priceInput = pkg.defaultPriceEgp.toString()
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = pkg.titleAr,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${pkg.totalDays} يوم • ${pkg.durationMonths} شهر • ${pkg.freeInvitations} دعوات",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "${pkg.defaultPriceEgp} ج.م",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = priceInput,
                    onValueChange = { priceInput = it },
                    label = { Text("السعر المدفوع بالجنيه (price_paid_egp)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { activateImmediately = !activateImmediately }
                ) {
                    Checkbox(
                        checked = activateImmediately,
                        onCheckedChange = { activateImmediately = it }
                    )
                    Text(
                        text = "تفعيل الاشتراك فوراً بحالة ACTIVE وإرسال إشعار التفعيل",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (errorMsg != null) {
                    Text(
                        text = errorMsg!!,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء")
                    }
                    Button(
                        onClick = {
                            if (fullName.isBlank() || phone.isBlank()) {
                                errorMsg = "يرجى إدخال اسم المشترك ورقم الهاتف"
                            } else {
                                onConfirm(
                                    generatedCode,
                                    fullName,
                                    phone,
                                    selectedGender,
                                    selectedPkg,
                                    priceInput.toIntOrNull() ?: selectedPkg.defaultPriceEgp,
                                    activateImmediately
                                )
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1.4f)
                            .testTag("confirm_create_member_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تفعيل وحفظ #${generatedCode}")
                    }
                }
            }
        }
    }
}

/**
 * Modal Dialog: ماسح وفاحص كود الاشتراك (QR & Code Verifier)
 */
@Composable
private fun QrAndCodeVerifierDialog(
    codeInput: String,
    verifiedSubscription: SubscriptionEntity?,
    feedbackMessage: String?,
    recentSubscriptions: List<SubscriptionEntity>,
    onInputChange: (String) -> Unit,
    onVerifyClick: () -> Unit,
    onSelectQuickCode: (String) -> Unit,
    onApprove: (SubscriptionEntity) -> Unit,
    onToggleFreeze: (SubscriptionEntity) -> Unit,
    onExtendDays: (SubscriptionEntity, Int) -> Unit,
    onUseInvitation: (SubscriptionEntity) -> Unit,
    onWhatsApp: (SubscriptionEntity) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        LuxuryGlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            highlighted = true
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "ماسح وفاحص كود العضوية (QR & Code Verifier)",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "أدخل كود المشترك (#KH...) للتحقق الفوري من صلاحية بطاقته والأيام المتبقية له:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = codeInput,
                        onValueChange = onInputChange,
                        label = { Text("كود العضوية (مثال: KH8492A)") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("verifier_code_input")
                    )

                    Button(
                        onClick = onVerifyClick,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .height(54.dp)
                            .testTag("verify_code_submit_button")
                    ) {
                        Text("تحقق الآن", fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Quick Select Chips from Registered Members
                Text(
                    text = "أكواد سريعة للفحص الفوري:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    recentSubscriptions.forEach { item ->
                        FilterChip(
                            selected = verifiedSubscription?.code == item.code,
                            onClick = { onSelectQuickCode(item.code) },
                            label = { Text("#${item.code} • ${item.full_name.substringBefore(" ")}") }
                        )
                    }
                }

                if (feedbackMessage != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = StatusExpiredRed.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, StatusExpiredRed)
                    ) {
                        Text(
                            text = feedbackMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            color = StatusExpiredRed,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                if (verifiedSubscription != null) {
                    val sub = verifiedSubscription
                    val liveRemaining = sub.computeLiveRemainingDays()
                    val isValidAccess = sub.status_code == "ACTIVE" && liveRemaining > 0

                    Spacer(modifier = Modifier.height(14.dp))

                    // 3D Digital Membership Pass Verification Card
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(
                            2.dp,
                            if (isValidAccess) StatusActiveGreen
                            else if (sub.status_code == "FROZEN") StatusFrozenCyan
                            else StatusExpiredRed
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            (if (isValidAccess) StatusActiveGreen else StatusExpiredRed).copy(alpha = 0.15f),
                                            Color.Transparent
                                        )
                                    )
                                )
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Verified,
                                        contentDescription = null,
                                        tint = if (isValidAccess) StatusActiveGreen else StatusExpiredRed,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Text(
                                        text = if (isValidAccess) "بطاقة صالحة للدخول الآن"
                                        else if (sub.status_code == "FROZEN") "البطاقة مجمدة مؤقتاً (العداد متوقف)"
                                        else "البطاقة غير مفعلة / منتهية",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = if (isValidAccess) StatusActiveGreen else StatusExpiredRed,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                SubscriptionStatusBadge(sub.status_code, sub.status_ar)
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = sub.full_name,
                                style = MaterialTheme.typography.headlineLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "كود العضوية: #${sub.code} • ${sub.gender_category} • ${sub.phone}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Big Live Remaining Days Counter
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "$liveRemaining",
                                            style = MaterialTheme.typography.displayMedium,
                                            color = if (sub.status_code == "FROZEN") StatusFrozenCyan else MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (sub.status_code == "FROZEN") "يوم متبقي (متوقف ❄️)"
                                            else "يوم متبقي من ${sub.total_days}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "${sub.freeze_days_available}",
                                            style = MaterialTheme.typography.displayMedium,
                                            color = StatusFrozenCyan,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "أيام تجميد متاحة",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "الباقة: ${sub.package_title} • تنتهي في: ${sub.end_date}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (sub.status_code == "PENDING") {
                                    Button(
                                        onClick = { onApprove(sub) },
                                        colors = ButtonDefaults.buttonColors(containerColor = StatusActiveGreen),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("تفعيل فوري")
                                    }
                                }
                                if (sub.status_code == "ACTIVE" || sub.status_code == "FROZEN") {
                                    OutlinedButton(
                                        onClick = { onToggleFreeze(sub) },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(if (sub.status_code == "FROZEN") "فك التجميد" else "تجميد")
                                    }
                                }
                                OutlinedButton(
                                    onClick = { onExtendDays(sub, 30) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("+30 يوم")
                                }
                                OutlinedButton(
                                    onClick = { onWhatsApp(sub) },
                                    border = BorderStroke(1.dp, WhatsAppGreen),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = WhatsAppGreen),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("واتساب")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
