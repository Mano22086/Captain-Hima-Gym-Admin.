package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

private val LuxuryDarkColorScheme = darkColorScheme(
    primary = FieryOrange,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF331400),
    onPrimaryContainer = FieryOrangeGlow,
    secondary = MetallicGold,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF2B220A),
    onSecondaryContainer = MetallicGold,
    tertiary = StatusFrozenCyan,
    background = LuxuryDarkBackground,
    onBackground = DarkModeTextPrimary,
    surface = LuxuryDarkGlassCard,
    onSurface = DarkModeTextPrimary,
    surfaceVariant = LuxuryDarkGlassElevated,
    onSurfaceVariant = DarkModeTextSecondary,
    outline = LuxuryDarkGlassBorder,
    error = StatusExpiredRed
)

private val RoyalLightColorScheme = lightColorScheme(
    primary = RoyalGold,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF9F1DC),
    onPrimaryContainer = Color(0xFF5C4304),
    secondary = MetallicGold,
    onSecondary = LightModeTextPrimary,
    secondaryContainer = Color(0xFFF4EBD0),
    onSecondaryContainer = LightModeTextPrimary,
    tertiary = FieryOrange,
    background = RoyalLightBackground,
    onBackground = LightModeTextPrimary,
    surface = RoyalLightCard,
    onSurface = LightModeTextPrimary,
    surfaceVariant = RoyalLightElevated,
    onSurfaceVariant = LightModeTextSecondary,
    outline = RoyalLightBorder,
    error = StatusExpiredRed
)

val LuxuryShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun CaptainHimaGymTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) LuxuryDarkColorScheme else RoyalLightColorScheme

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = LuxuryShapes,
            content = content
        )
    }
}
