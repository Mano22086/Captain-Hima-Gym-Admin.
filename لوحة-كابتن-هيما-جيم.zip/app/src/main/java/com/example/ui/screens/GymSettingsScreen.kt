package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.GymConfigEntity
import com.example.data.remote.SupabaseSyncStatus
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.StatusActiveGreen

@Composable
fun GymSettingsScreen(
    gymConfig: GymConfigEntity,
    isDarkTheme: Boolean,
    syncStatus: SupabaseSyncStatus,
    initialSupabaseUrl: String = "",
    initialSupabaseKey: String = "",
    onSetDarkTheme: (Boolean) -> Unit,
    onSaveConfig: (GymConfigEntity) -> Unit,
    onSaveSupabaseCredentials: (String, String) -> Unit = { _, _ -> },
    onSyncSupabase: () -> Unit,
    onOpenUrl: (String) -> Unit
) {
    var adminEmail by remember { mutableStateOf(gymConfig.admin_email) }
    var phoneDisplay by remember { mutableStateOf(gymConfig.phone_display) }
    var whatsappIntl by remember { mutableStateOf(gymConfig.whatsapp_intl) }
    var addressAr by remember { mutableStateOf(gymConfig.address_ar) }
    var workingHours by remember { mutableStateOf(gymConfig.working_hours) }
    var pkg1mPrice by remember { mutableStateOf(gymConfig.pkg_1m_price) }
    var pkg3mPrice by remember { mutableStateOf(gymConfig.pkg_3m_price) }
    var pkg6mPrice by remember { mutableStateOf(gymConfig.pkg_6m_price) }
    var pkg12mPrice by remember { mutableStateOf(gymConfig.pkg_12m_price) }
    var tiktokUrl by remember { mutableStateOf(gymConfig.tiktok_url) }
    var facebookUrl by remember { mutableStateOf(gymConfig.facebook_page_url) }
    var instagramUrl by remember { mutableStateOf(gymConfig.instagram_url) }
    var googleMapsUrl by remember { mutableStateOf(gymConfig.google_maps_url) }

    var supabaseUrlInput by remember(initialSupabaseUrl) { mutableStateOf(initialSupabaseUrl) }
    var supabaseKeyInput by remember(initialSupabaseKey) { mutableStateOf(initialSupabaseKey) }

    LaunchedEffect(gymConfig) {
        adminEmail = gymConfig.admin_email
        phoneDisplay = gymConfig.phone_display
        whatsappIntl = gymConfig.whatsapp_intl
        addressAr = gymConfig.address_ar
        workingHours = gymConfig.working_hours
        pkg1mPrice = gymConfig.pkg_1m_price
        pkg3mPrice = gymConfig.pkg_3m_price
        pkg6mPrice = gymConfig.pkg_6m_price
        pkg12mPrice = gymConfig.pkg_12m_price
        tiktokUrl = gymConfig.tiktok_url
        facebookUrl = gymConfig.facebook_page_url
        instagramUrl = gymConfig.instagram_url
        googleMapsUrl = gymConfig.google_maps_url
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Visual Theme Selector (3D Glass Dark vs Royal Light Gold)
        item {
            LuxuryGlassCard(highlighted = true) {
                Text(
                    text = "الهوية البصرية والمظهر (3D Glass Luxury UI)",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "اختر بين المظهر الداكن الناري (#050507 + #FF5E00) أو المظهر الفاتح الملكي (#FAF8F3 + #D4AF37):",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilterChip(
                        selected = isDarkTheme,
                        onClick = { onSetDarkTheme(true) },
                        leadingIcon = {
                            Icon(Icons.Default.DarkMode, contentDescription = null, modifier = Modifier.size(18.dp))
                        },
                        label = { Text("المظهر الداكن الناري (Dark)") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("settings_dark_mode_chip")
                    )
                    FilterChip(
                        selected = !isDarkTheme,
                        onClick = { onSetDarkTheme(false) },
                        leadingIcon = {
                            Icon(Icons.Default.LightMode, contentDescription = null, modifier = Modifier.size(18.dp))
                        },
                        label = { Text("المظهر الملكي الذهبي (Light)") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("settings_light_mode_chip")
                    )
                }
            }
        }

        // 2. Package Prices Editor (gym_config id = 'main')
        item {
            LuxuryGlassCard(accentColor = MetallicGold, highlighted = true) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Payments, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column {
                        Text(
                            text = "أسعار الباقات الأربع بعد الخصم (gym_config • id = 'main')",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "تتحدث الأسعار فوراً في تطبيق العميل وحاسبة الخصم",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = pkg1mPrice,
                        onValueChange = { pkg1mPrice = it },
                        label = { Text("شهر واحد (pkg_1m_price)") },
                        suffix = { Text("ج.م") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_pkg_1m_price")
                    )

                    OutlinedTextField(
                        value = pkg3mPrice,
                        onValueChange = { pkg3mPrice = it },
                        label = { Text("3 شهور (pkg_3m_price)") },
                        suffix = { Text("ج.م") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_pkg_3m_price")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = pkg6mPrice,
                        onValueChange = { pkg6mPrice = it },
                        label = { Text("6 شهور (pkg_6m_price)") },
                        suffix = { Text("ج.م") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_pkg_6m_price")
                    )

                    OutlinedTextField(
                        value = pkg12mPrice,
                        onValueChange = { pkg12mPrice = it },
                        label = { Text("سنة VIP (pkg_12m_price)") },
                        suffix = { Text("ج.م") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_pkg_12m_price")
                    )
                }
            }
        }

        // 3. Contact, Address & Working Hours
        item {
            LuxuryGlassCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Phone, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(
                        text = "بيانات التواصل والعنوان ومواعيد العمل",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = adminEmail,
                    onValueChange = { adminEmail = it },
                    label = { Text("البريد الرسمي للإدارة (admin_email)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = phoneDisplay,
                        onValueChange = { phoneDisplay = it },
                        label = { Text("رقم الهاتف المعروض (phone_display)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_phone_display")
                    )

                    OutlinedTextField(
                        value = whatsappIntl,
                        onValueChange = { whatsappIntl = it },
                        label = { Text("واتساب الدولي (whatsapp_intl)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_whatsapp_intl")
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = addressAr,
                    onValueChange = { addressAr = it },
                    label = { Text("عنوان النادي بالتفصيل (address_ar)") },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_address_ar")
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = workingHours,
                    onValueChange = { workingHours = it },
                    label = { Text("مواعيد العمل (working_hours)") },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_working_hours")
                )
            }
        }

        // 4. Social Media & Google Maps Links
        item {
            LuxuryGlassCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(
                        text = "روابط التواصل الاجتماعي وخرائط جوجل",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = tiktokUrl,
                    onValueChange = { tiktokUrl = it },
                    label = { Text("رابط تيك توك الرسمي (tiktok_url)") },
                    trailingIcon = {
                        IconButton(onClick = { onOpenUrl(tiktokUrl) }) {
                            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "فتح الرابط")
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = facebookUrl,
                    onValueChange = { facebookUrl = it },
                    label = { Text("رابط صفحة فيسبوك (facebook_page_url)") },
                    trailingIcon = {
                        IconButton(onClick = { onOpenUrl(facebookUrl) }) {
                            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "فتح الرابط")
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = instagramUrl,
                    onValueChange = { instagramUrl = it },
                    label = { Text("رابط حساب إنستجرام (instagram_url)") },
                    trailingIcon = {
                        IconButton(onClick = { onOpenUrl(instagramUrl) }) {
                            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "فتح الرابط")
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = googleMapsUrl,
                    onValueChange = { googleMapsUrl = it },
                    label = { Text("رابط موقع الجيم على خرائط جوجل (google_maps_url)") },
                    trailingIcon = {
                        IconButton(onClick = { onOpenUrl(googleMapsUrl) }) {
                            Icon(Icons.Default.LocationOn, contentDescription = "فتح الخريطة")
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        onSaveConfig(
                            GymConfigEntity(
                                id = "main",
                                admin_email = adminEmail.trim(),
                                phone_display = phoneDisplay.trim(),
                                whatsapp_intl = whatsappIntl.trim(),
                                address_ar = addressAr.trim(),
                                working_hours = workingHours.trim(),
                                pkg_1m_price = pkg1mPrice.trim(),
                                pkg_3m_price = pkg3mPrice.trim(),
                                pkg_6m_price = pkg6mPrice.trim(),
                                pkg_12m_price = pkg12mPrice.trim(),
                                tiktok_url = tiktokUrl.trim(),
                                facebook_page_url = facebookUrl.trim(),
                                instagram_url = instagramUrl.trim(),
                                google_maps_url = googleMapsUrl.trim()
                            )
                        )
                    },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("save_gym_config_button")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "حفظ وتحديث إعدادات النادي وأسعار الباقات فوراً",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // 5. Supabase Sync & Live Connection Card
        item {
            LuxuryGlassCard(
                accentColor = if (syncStatus.isConnected) StatusActiveGreen else MaterialTheme.colorScheme.primary,
                highlighted = !syncStatus.isConnected
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "إعدادات وحالة الربط السحابي مع Supabase",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = syncStatus.statusMessageAr,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (syncStatus.isConnected) StatusActiveGreen else MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = supabaseUrlInput,
                    onValueChange = { supabaseUrlInput = it },
                    label = { Text("رابط مشروع Supabase (مثال: https://xxxx.supabase.co)") },
                    placeholder = { Text("https://your-project-ref.supabase.co") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_supabase_url")
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = supabaseKeyInput,
                    onValueChange = { supabaseKeyInput = it },
                    label = { Text("مفتاح Supabase (SUPABASE_ANON_KEY / sb_publishable_...)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_supabase_key")
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            onSaveSupabaseCredentials(supabaseUrlInput, supabaseKeyInput)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.4f)
                            .testTag("save_supabase_credentials_button")
                    ) {
                        Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("حفظ الاتصال والمزامنة الآن", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onSyncSupabase,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إعادة فحص المزامنة")
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(88.dp)) }
    }
}
