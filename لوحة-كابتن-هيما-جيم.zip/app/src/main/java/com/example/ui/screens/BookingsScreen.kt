package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.BookingEntity
import com.example.data.model.GymDateUtils
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.components.SubscriptionStatusBadge
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusPendingAmber
import com.example.ui.theme.StatusRejectedRose
import com.example.ui.theme.WhatsAppGreen

@Composable
fun BookingsScreen(
    bookings: List<BookingEntity>,
    onUpdateBookingStatus: (BookingEntity, String) -> Unit,
    onDeleteBooking: (String) -> Unit
) {
    var selectedFilter by remember { mutableStateOf("ALL") }
    val context = LocalContext.current

    val filtered = remember(bookings, selectedFilter) {
        if (selectedFilter == "ALL") bookings
        else bookings.filter { it.status == selectedFilter }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                text = "إدارة طلبات الحجز والحصص الجماعية (bookings)",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "مراجعة حجوزات الحصص الجماعية والسبا والباقات الواردة من تطبيق العميل",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "ALL" to "الكل (${bookings.size})",
                    "PENDING" to "قيد الانتظار (${bookings.count { it.status == "PENDING" }})",
                    "ACTIVE" to "مؤكد ACTIVE (${bookings.count { it.status == "ACTIVE" }})",
                    "REJECTED" to "مرفوض REJECTED (${bookings.count { it.status == "REJECTED" }})"
                ).forEach { (key, label) ->
                    FilterChip(
                        selected = selectedFilter == key,
                        onClick = { selectedFilter = key },
                        label = { Text(label) },
                        modifier = Modifier.testTag("booking_filter_$key")
                    )
                }
            }
        }

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.EventAvailable,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "لا توجد طلبات حجز في هذا التصنيف حالياً",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filtered, key = { it.id }) { booking ->
                    val statusAr = GymDateUtils.statusArabicLabel(booking.status)
                    val accent = when (booking.status) {
                        "PENDING" -> StatusPendingAmber
                        "ACTIVE" -> StatusActiveGreen
                        else -> StatusRejectedRose
                    }

                    LuxuryGlassCard(
                        accentColor = accent,
                        highlighted = booking.status == "PENDING",
                        modifier = Modifier.testTag("booking_card_${booking.id}")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${booking.order_number} • كود مرجعي: #${booking.reference_code}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = booking.full_name,
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            SubscriptionStatusBadge(booking.status, statusAr)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "${booking.booking_type}: ${booking.selected_item_name}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "القسم: ${booking.gender_category} • السعر: ${booking.price_egp} ج.م • الهاتف: ${booking.phone}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        Icons.Default.CalendarMonth,
                                        contentDescription = null,
                                        tint = MetallicGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "الموعد المفضل: ${booking.preferred_date_time}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MetallicGold
                                    )
                                }
                                if (booking.notes.isNotBlank()) {
                                    Text(
                                        text = "ملاحظات العميل: ${booking.notes}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (booking.status != "ACTIVE") {
                                Button(
                                    onClick = { onUpdateBookingStatus(booking, "ACTIVE") },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = StatusActiveGreen,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تأكيد الحجز")
                                }
                            }

                            if (booking.status != "REJECTED") {
                                OutlinedButton(
                                    onClick = { onUpdateBookingStatus(booking, "REJECTED") },
                                    border = BorderStroke(1.dp, StatusRejectedRose),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRejectedRose),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("رفض")
                                }
                            }

                            OutlinedButton(
                                onClick = {
                                    val digits = booking.phone.replace(Regex("[^0-9]"), "")
                                    val intl = if (digits.startsWith("0")) "2$digits" else digits
                                    val msg = "مرحباً ${booking.full_name}، بخصوص حجزك (${booking.selected_item_name}) في كابتن هيما جيم بموعد ${booking.preferred_date_time}:"
                                    runCatching {
                                        context.startActivity(
                                            Intent(
                                                Intent.ACTION_VIEW,
                                                Uri.parse("https://wa.me/$intl?text=${Uri.encode(msg)}")
                                            )
                                        )
                                    }
                                },
                                border = BorderStroke(1.dp, WhatsAppGreen),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = WhatsAppGreen),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = "واتساب", modifier = Modifier.size(16.dp))
                            }

                            IconButton(onClick = { onDeleteBooking(booking.id) }) {
                                Icon(
                                    Icons.Default.DeleteOutline,
                                    contentDescription = "حذف الحجز",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
                item { Spacer(modifier = Modifier.height(88.dp)) }
            }
        }
    }
}
